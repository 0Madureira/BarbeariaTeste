// Replaced at build time by scripts/build.mjs. Local preview reads public/ directly.
export const ASSET_MAP={};
