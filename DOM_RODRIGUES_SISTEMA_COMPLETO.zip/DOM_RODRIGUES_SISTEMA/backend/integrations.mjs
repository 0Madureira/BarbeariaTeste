import { fail,nowSeconds,uid,localParts,addDays,textValue,safeURL } from './domain.mjs';
import { first,rows,stmt,auditStmt,digest,secretEqual } from './auth.mjs';
export function integrationStatus(env){const demo=env.DEMO_MODE==='true';return {demo,asaas:{mode:env.ASAAS_MODE||'sandbox',configured:!!(env.ASAAS_API_KEY&&env.ASAAS_WEBHOOK_TOKEN&&env.ASAAS_CHECKOUT_ORIGIN),production_enabled:!demo&&env.PRODUCTION_PAYMENTS_ENABLED==='true'},whatsapp:{configured:!!(env.META_ACCESS_TOKEN&&env.META_PHONE_NUMBER_ID&&env.META_GRAPH_VERSION),enabled:!demo&&env.WHATSAPP_ENABLED==='true'},phone_verification_configured:!!(env.META_ACCESS_TOKEN&&env.META_AUTH_TEMPLATE&&env.META_GRAPH_VERSION&&env.META_PHONE_NUMBER_ID),storage:!!env.BUCKET};}
function externalFetch(env,...args){return (env.PROVIDER_FETCH||fetch)(...args);}
export async function asaasRequest(env,path,method='GET',data){
  if(!env.ASAAS_API_KEY)fail(503,'Asaas sandbox ainda não configurado.','asaas_unconfigured');
  const production=env.ASAAS_MODE==='production';
  if(production&&(env.PRODUCTION_PAYMENTS_ENABLED!=='true'||env.DEMO_MODE==='true'))fail(503,'Cobranças de produção estão bloqueadas.');
  const base=production?'https://api.asaas.com/v3':'https://api-sandbox.asaas.com/v3';
  const response=await externalFetch(env,base+path,{method,headers:{'access_token':env.ASAAS_API_KEY,'User-Agent':'DomRodrigues/1.0','Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data),signal:AbortSignal.timeout(15000)});
  const result=await response.json().catch(()=>({}));if(!response.ok)fail(502,'O provedor de pagamentos não concluiu a operação. Consulte o painel e tente novamente.','provider_error');return result;
}
export async function createHostedCheckout(env,request,sub){
  if(!env.ASAAS_WEBHOOK_TOKEN||env.ASAAS_WEBHOOK_TOKEN.length<32||!env.ASAAS_CHECKOUT_ORIGIN)fail(503,'Configure o Asaas sandbox, o webhook e o domínio de checkout validado.','asaas_unconfigured');
  const origin=new URL(request.url).origin;
  const data=await asaasRequest(env,'/checkouts','POST',{billingTypes:['CREDIT_CARD'],chargeTypes:['RECURRENT'],minutesToExpire:60,externalReference:sub.id,callback:{successUrl:origin+'/conta?checkout=retorno',cancelUrl:origin+'/conta?checkout=cancelado',expiredUrl:origin+'/conta?checkout=expirado'},items:[{name:sub.plan_name,quantity:1,value:sub.price_cents/100}],subscription:{cycle:'MONTHLY',nextDueDate:localParts().day}});
  if(!data.id)fail(502,'O Asaas não retornou a identificação do checkout.');
  const checkoutOrigin=new URL(env.ASAAS_CHECKOUT_ORIGIN);
  if(!/^https:$/.test(checkoutOrigin.protocol)||!/(^|\.)asaas\.com$/.test(checkoutOrigin.hostname))fail(503,'Domínio de checkout inválido.');
  const url=new URL('/checkoutSession/show',checkoutOrigin);url.searchParams.set('id',data.id);
  await stmt(env,'UPDATE subscriptions SET checkout_id=?,checkout_url=? WHERE id=?',data.id,url.href,sub.id).run();return {checkout_url:url.href,subscription_id:sub.id};
}
export async function reconcileAsaasPayment(env,paymentId,eventId,eventType){
  // Read authoritative current status: handle duplicate, delayed and out-of-order webhooks.
  const pay=await asaasRequest(env,'/payments/'+encodeURIComponent(paymentId));
  let sub=await first(env,'SELECT * FROM subscriptions WHERE provider_id=? OR checkout_id=? OR id=?',pay.subscription||'',pay.checkoutSession||'',pay.externalReference||'');
  if(!sub&&pay.subscription){const ps=await asaasRequest(env,'/subscriptions/'+encodeURIComponent(pay.subscription));sub=await first(env,'SELECT * FROM subscriptions WHERE id=?',ps.externalReference||'');}
  if(!sub)return {ignored:true,reason:'unmatched_subscription'};
  if(sub.provider_mode!==(env.ASAAS_MODE==='production'?'production':'sandbox'))fail(409,'O evento pertence a outro ambiente.');
  const paid=['CONFIRMED','RECEIVED','RECEIVED_IN_CASH'].includes(pay.status);
  const refunded=['REFUNDED','REFUND_REQUESTED','CHARGEBACK_REQUESTED','CHARGEBACK_DISPUTE','AWAITING_CHARGEBACK_REVERSAL'].includes(pay.status);
  const today=localParts().day;
  const due=/^\d{4}-\d{2}-\d{2}$/.test(pay.dueDate||'')?pay.dueDate:today;
  const date=new Date(due+'T12:00:00-03:00');const month=date.getUTCMonth();const day=date.getUTCDate();date.setUTCDate(1);date.setUTCMonth(month+1);const daysInMonth=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,0)).getUTCDate();date.setUTCDate(Math.min(day,daysInMonth));
  const periodEnd=Math.floor(Date.parse(date.toISOString().slice(0,10)+'T00:00:00-03:00')/1000);
  const amount=Math.round(Number(pay.value)*100);if(paid&&amount!==sub.price_cents)fail(409,'Valor da cobrança divergente do contrato.','payment_amount_mismatch');
  const statements=[stmt(env,'INSERT INTO webhook_events(id,provider,event_type,received_at) VALUES(?,?,?,?)',eventId,'asaas',eventType,nowSeconds())];
  if(pay.subscription)statements.push(stmt(env,'UPDATE subscriptions SET provider_id=? WHERE id=?',pay.subscription,sub.id));
  if(paid){statements.push(stmt(env,"INSERT INTO subscription_payments(id,subscription_id,provider_payment_id,amount_cents,status,paid_at,period_end,provider_mode,settled) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(provider_payment_id) DO UPDATE SET status='confirmed',settled=MAX(subscription_payments.settled,excluded.settled)",uid(),sub.id,pay.id,amount,'confirmed',nowSeconds(),periodEnd,sub.provider_mode,['RECEIVED','RECEIVED_IN_CASH'].includes(pay.status)?1:0));
    statements.push(stmt(env,"UPDATE subscriptions SET status=CASE WHEN cancel_at_end=1 THEN 'cancelled' ELSE 'active' END,valid_until=MAX(valid_until,?) WHERE id=?",periodEnd,sub.id));
  }else if(refunded){statements.push(stmt(env,"UPDATE subscription_payments SET status='refunded' WHERE provider_payment_id=?",pay.id));statements.push(stmt(env,"UPDATE subscriptions SET valid_until=COALESCE((SELECT MAX(period_end) FROM subscription_payments WHERE subscription_id=? AND status='confirmed'),0) WHERE id=?",sub.id,sub.id));
  }else if(pay.status==='OVERDUE'){statements.push(stmt(env,"UPDATE subscriptions SET status=CASE WHEN cancel_at_end=1 THEN 'cancelled' ELSE 'past_due' END WHERE id=?",sub.id));}
  statements.push(auditStmt(env,null,'asaas.reconcile',sub.id,{event_type:eventType,payment_id:pay.id,status:pay.status}));
  try{await env.DB.batch(statements);}catch(e){if(String(e).includes('webhook_events.id'))return {duplicate:true};throw e;}
  if(paid)await enqueueNotification(env,sub.user_id,'subscription_paid',pay.id,{plan:sub.plan_name},'subscription_paid:'+pay.id);
  return {processed:true};
}
export async function enqueueNotification(env,userId,kind,entityId,payload={},dedupeKey){const user=await first(env,'SELECT consent_service FROM users WHERE id=?',userId);if(!user?.consent_service)return;const cfg=await first(env,'SELECT value FROM settings WHERE id=1');const settings=cfg?JSON.parse(cfg.value):{};if(settings.notification_types?.[kind]===false)return;const configured=integrationStatus(env).whatsapp;const status=configured.configured&&configured.enabled?'pending':'unconfigured';await stmt(env,'INSERT OR IGNORE INTO notifications(id,user_id,kind,entity_id,dedupe_key,payload,status,next_attempt_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',uid(),userId,kind,entityId,dedupeKey||kind+':'+entityId,JSON.stringify(payload),status,nowSeconds(),nowSeconds()).run();}
export async function sendOTP(env,phone,code){
  if(!integrationStatus(env).phone_verification_configured)fail(503,'A verificação do telefone precisa ser configurada antes do cadastro de clientes.','phone_provider_unconfigured');
  const r=await externalFetch(env,`https://graph.facebook.com/${env.META_GRAPH_VERSION}/${env.META_PHONE_NUMBER_ID}/messages`,{method:'POST',headers:{Authorization:'Bearer '+env.META_ACCESS_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to:phone,type:'template',template:{name:env.META_AUTH_TEMPLATE,language:{code:'pt_BR'},components:[{type:'body',parameters:[{type:'text',text:code}]},{type:'button',sub_type:'url',index:'0',parameters:[{type:'text',text:code}]}]}}),signal:AbortSignal.timeout(15000)});if(!r.ok)fail(502,'Não foi possível enviar o código pelo canal oficial. Tente novamente mais tarde.');
}
export async function processNotifications(env){
  const cfg=await first(env,'SELECT value FROM settings WHERE id=1');if(!cfg)return {sent:0};const settings=JSON.parse(cfg.value);const state=integrationStatus(env).whatsapp;
  if(!state.enabled||!state.configured)return {sent:0,configuration_pending:true};
  // Never resend an ambiguous request automatically: it may already have reached Meta.
  await stmt(env,"UPDATE notifications SET status='unknown',last_error='Resultado de envio desconhecido; conferir no provedor antes de reenviar.' WHERE status='processing' AND updated_at<?",nowSeconds()-300).run();
  const queue=await rows(env,"SELECT n.*,u.phone,u.consent_service FROM notifications n JOIN users u ON u.id=n.user_id WHERE n.status IN('pending','failed') AND n.attempts<5 AND n.next_attempt_at<=? ORDER BY n.next_attempt_at LIMIT 10",nowSeconds());let sent=0;
  for(const n of queue){
    if(!n.consent_service||settings.notification_types?.[n.kind]===false){await stmt(env,"UPDATE notifications SET status='cancelled' WHERE id=?",n.id).run();continue;}
    const template=settings.whatsapp_templates?.[n.kind];if(!template){await stmt(env,"UPDATE notifications SET status='unconfigured',last_error='Modelo aprovado não configurado.' WHERE id=?",n.id).run();continue;}
    const claim=uid();const claimed=await stmt(env,"UPDATE notifications SET status='processing',claim_token=?,attempts=attempts+1,updated_at=? WHERE id=? AND status IN('pending','failed') RETURNING id",claim,nowSeconds(),n.id).first();if(!claimed)continue;
    try{
      const p=JSON.parse(n.payload);const components=p.parameters?.length?[{type:'body',parameters:p.parameters.map(v=>({type:'text',text:String(v)}))}]:[];
      const response=await externalFetch(env,`https://graph.facebook.com/${env.META_GRAPH_VERSION}/${env.META_PHONE_NUMBER_ID}/messages`,{method:'POST',headers:{Authorization:'Bearer '+env.META_ACCESS_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to:n.phone,type:'template',template:{name:template,language:{code:'pt_BR'},components}}),signal:AbortSignal.timeout(15000)});
      const data=await response.json();if(!response.ok){const retryable=response.status===429;await stmt(env,"UPDATE notifications SET status=?,last_error=?,next_attempt_at=?,updated_at=? WHERE id=? AND claim_token=?",retryable?'failed':'unconfigured','O provedor recusou o envio (HTTP '+response.status+').',nowSeconds()+300*2**n.attempts,nowSeconds(),n.id,claim).run();continue;}
      const providerId=data.messages?.[0]?.id;if(!providerId)throw Error('ambiguous');await stmt(env,"UPDATE notifications SET status='sent',provider_id=?,updated_at=?,last_error=NULL WHERE id=? AND claim_token=?",providerId,nowSeconds(),n.id,claim).run();sent++;
    }catch{await stmt(env,"UPDATE notifications SET status='unknown',last_error='Envio sem confirmação; verifique no provedor.',updated_at=? WHERE id=? AND claim_token=?",nowSeconds(),n.id,claim).run();}
  }return {sent};
}
export async function metaSignatureValid(env,request,raw){if(!env.META_APP_SECRET)return false;const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.META_APP_SECRET),{name:'HMAC',hash:'SHA-256'},false,['sign']);const signed=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(raw));const sig='sha256='+Array.from(new Uint8Array(signed),x=>x.toString(16).padStart(2,'0')).join('');return secretEqual(sig,request.headers.get('x-hub-signature-256'));}
