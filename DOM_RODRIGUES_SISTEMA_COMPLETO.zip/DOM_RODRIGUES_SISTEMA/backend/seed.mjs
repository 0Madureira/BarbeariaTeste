import {DEFAULT_SETTINGS,uid,nowSeconds,localParts,addDays,zonedEpoch,weekday} from './domain.mjs';
import {stmt,first} from './auth.mjs';
export const INITIAL_SERVICES=[
 ['corte','Corte','Corte completo para o seu estilo.','cortes',3500,40],
 ['corte-simples','Corte simples','Acerto prático, com a identidade Dom.','cortes',2500,25],
 ['barba','Barba','Desenho e cuidado com a sua barba.','barbas',2500,25],
 ['acabamento','Acabamento','Os detalhes que completam o corte.','detalhes',1500,15],
 ['sobrancelha','Sobrancelha','Alinhamento e acabamento.','detalhes',1500,15],
 ['pigmentacao','Pigmentação','Uniformização da cor.','tratamentos',2000,30],
 ['relaxamento','Relaxamento capilar','Tratamento e cuidado dos fios.','tratamentos',3000,45],
 ['combo','Combo cabelo + barba + sobrancelha','O cuidado completo da sua assinatura.','combos',7000,70]
];
export async function baseStatements(env){return [stmt(env,'INSERT OR IGNORE INTO settings(id,value) VALUES(1,?)',JSON.stringify(DEFAULT_SETTINGS)),...INITIAL_SERVICES.map((s,i)=>stmt(env,'INSERT OR IGNORE INTO services(id,name,description,category,price_cents,duration_minutes,sort_order) VALUES(?,?,?,?,?,?,?)',...s,i)),stmt(env,"INSERT OR IGNORE INTO barbers(id,name,bio,is_owner,commission_bps,online) VALUES('rodrigues','Rodrigues','Dom Rodrigues Barbearia',1,0,0)"),...INITIAL_SERVICES.map(s=>stmt(env,"INSERT OR IGNORE INTO barber_services(barber_id,service_id) VALUES('rodrigues',?)",s[0])),stmt(env,"INSERT OR IGNORE INTO plans(id,name,price_cents) VALUES('clube-corte','Clube Corte',15000)"),stmt(env,"INSERT OR IGNORE INTO plans(id,name,price_cents) VALUES('clube-completo','Clube Corte + Barba',20000)"),stmt(env,"INSERT OR IGNORE INTO plan_services(plan_id,service_id) VALUES('clube-corte','corte')"),stmt(env,"INSERT OR IGNORE INTO plan_services(plan_id,service_id) VALUES('clube-completo','corte')"),stmt(env,"INSERT OR IGNORE INTO plan_services(plan_id,service_id) VALUES('clube-completo','barba')")];}
export async function seedDemo(env){
  const existing=await first(env,"SELECT id FROM users WHERE id='demo-admin'");if(existing)return;
  const now=nowSeconds(),today=localParts().day;
  const s=await baseStatements(env);
  s.push(stmt(env,"INSERT INTO users(id,role,name,phone,verified,consent_service,created_at,updated_at) VALUES('demo-admin','admin','Rodrigues · demonstração','5521999990000',1,0,?,?)",now,now));
  const names=['Cliente Demonstração','Rafael · demonstração','Lucas · demonstração','Marcos · demonstração','Bruno · demonstração','André · demonstração','Paulo · demonstração','Eduardo · demonstração','Renan · demonstração','Felipe · demonstração','Diego · demonstração','Carlos · demonstração','João · demonstração','Gustavo · demonstração','Leonardo · demonstração','Gabriel · demonstração','Vitor · demonstração','Thiago · demonstração','Cliente sem retorno 1 · demo','Cliente sem retorno 2 · demo','Cliente sem retorno 3 · demo'];
  names.forEach((name,i)=>s.push(stmt(env,'INSERT INTO users(id,role,name,phone,verified,consent_service,created_at,updated_at) VALUES(?,?,?,?,1,1,?,?)','demo-customer-'+i,'customer',name,'552199999'+String(i+1).padStart(4,'0'),now-120*86400,now)));
  s.push(stmt(env,"INSERT INTO barbers(id,name,bio,online,commission_bps) VALUES('demo-barber-1','Barbeiro 2 · demo','Perfil ilustrativo. Substitua por um profissional autorizado.',1,4000)"),stmt(env,"INSERT INTO barbers(id,name,bio,online,commission_bps) VALUES('demo-barber-2','Barbeiro 3 · demo','Perfil ilustrativo. Substitua por um profissional autorizado.',1,4000)"),stmt(env,"UPDATE barbers SET online=1 WHERE id='rodrigues'"));
  for(const b of ['rodrigues','demo-barber-1','demo-barber-2']){for(const se of INITIAL_SERVICES)s.push(stmt(env,'INSERT OR IGNORE INTO barber_services(barber_id,service_id) VALUES(?,?)',b,se[0]));for(let d=0;d<7;d++){s.push(stmt(env,'INSERT INTO weekly_hours(id,barber_id,weekday,start_minute,end_minute) VALUES(?,?,?,?,?)',uid(),b,d,540,720),stmt(env,'INSERT INTO weekly_hours(id,barber_id,weekday,start_minute,end_minute) VALUES(?,?,?,?,?)',uid(),b,d,780,1200));}}
  // Seed runs only after an explicit demonstration action. All names and values are illustrative.
  s.push(stmt(env,'UPDATE plans SET for_sale=1 WHERE id IN(?,?)','clube-corte','clube-completo'));
  await env.DB.batch(s);
  const batches=[];
  for(let d=-6;d<=6;d++){
    const day=addDays(today,d);
    for(let b=0;b<3;b++){
      const barber=['rodrigues','demo-barber-1','demo-barber-2'][b];
      const count=d===0?5:(d<0?2:1);
      for(let j=0;j<count;j++){
        const service=INITIAL_SERVICES[(b+j+d+14)%3];const minute=[540,600,660,840,960][j]+b*5;
        const id='demo-appointment-'+d+'-'+b+'-'+j;const start=zonedEpoch(day,minute),end=start+service[5]*60;
        const customer='demo-customer-'+(1+((d+7)*3+b+j)%17);
        const status=d<0||(d===0&&end<now-600)?'completed':d===0&&start<=now&&end>now?'in_service':d===0&&start>now&&start<now+1800?'waiting':'booked';
        // Historical completed rows do not count toward future limits.
        batches.push(stmt(env,'INSERT INTO appointments(id,customer_id,barber_id,service_id,starts_at,ends_at,local_day,start_minute,end_minute,service_name,barber_name,price_cents,duration_minutes,commission_bps,owner_snapshot,admin_override,request_key,request_fingerprint,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)',id,customer,barber,service[0],start,end,day,minute,minute+service[5],service[1],b===0?'Rodrigues':'Barbeiro '+(b+1)+' · demo',service[4],service[5],b===0?0:4000,b===0?1:0,id,id,start-86400,start));
        if(status==='completed'){batches.push(stmt(env,"UPDATE appointments SET status='in_service' WHERE id=?",id),stmt(env,"UPDATE appointments SET status='completed',charged_cents=price_cents,completed_at=?,updated_at=? WHERE id=?",end,end,id),stmt(env,"INSERT INTO receipts(id,appointment_id,amount_cents,method,received_at,request_key,created_by) VALUES(?,?,?,'Pix',?,?,'demo-admin')",'receipt-'+id,id,service[4],end,'receipt-'+id));}
        else if(status!=='booked')batches.push(stmt(env,'UPDATE appointments SET status=?,checked_in_at=?,updated_at=? WHERE id=?',status,start-300,now,id));
      }
    }
  }
  // Keep transactions small enough for real D1 binding limits.
  for(let i=0;i<batches.length;i+=60)await env.DB.batch(batches.slice(i,i+60));
  for(let i=0;i<3;i++){
    const day=addDays(today,-(35+i*25)),start=zonedEpoch(day,600),id='demo-old-'+i;
    await env.DB.batch([stmt(env,'INSERT INTO appointments(id,customer_id,barber_id,service_id,starts_at,ends_at,local_day,start_minute,end_minute,service_name,barber_name,price_cents,duration_minutes,commission_bps,owner_snapshot,admin_override,request_key,request_fingerprint,created_at,updated_at) VALUES(?,?,?,\'corte\',?,?,?,600,640,\'Corte\',\'Rodrigues\',3500,40,0,1,1,?,?,?,?)',id,'demo-customer-'+(18+i),'rodrigues',start,start+2400,day,id,id,start,start),stmt(env,"UPDATE appointments SET status='completed',charged_cents=3500,completed_at=?,updated_at=? WHERE id=?",start+2400,start+2400,id)]);
  }
}
