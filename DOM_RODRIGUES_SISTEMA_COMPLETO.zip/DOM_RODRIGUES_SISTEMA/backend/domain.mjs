// Domain functions have no storage or provider dependencies.
export const ZONE = 'America/Sao_Paulo';
export const ACTIVE = ['booked','waiting','in_service'];
export const STATUS = {booked:'Agendado',waiting:'Aguardando',in_service:'Em atendimento',completed:'Concluído',cancelled:'Cancelado',no_show:'Falta'};
export const DEFAULT_SETTINGS = {
  minimum_notice_minutes:60,horizon_days:30,cancellation_minutes:120,max_future_bookings:1,
  slot_minutes:5,inactive_days:30,business_name:'Dom Rodrigues Barbearia',
  address:'Rua Luiz Sobral, 492, Califórnia, Nova Iguaçu/RJ',phone:'5521970594489',
  instagram:'domr.rodrigues2026',subscription_commission_mode:null,
  notification_types:{booking_confirmation:true,reminder_24h:true,booking_cancelled:true,booking_rescheduled:true,subscription_paid:true,subscription_due:true},
  whatsapp_templates:{},payment_methods:['Pix','Dinheiro','Cartão de débito','Cartão de crédito','Outros'],
  expense_categories:['Aluguel','Água e energia','Produtos','Manutenção','Outras despesas'],
  privacy_contact:'Fale com Rodrigues na barbearia para exercer seus direitos sobre seus dados.'
};
export class HttpError extends Error { constructor(status, message, code='request_error'){super(message);this.status=status;this.code=code;} }
export function fail(status,message,code){throw new HttpError(status,message,code);}
export const nowSeconds=()=>Math.floor(Date.now()/1000);
export const uid=()=>crypto.randomUUID();
export function textValue(v,min=1,max=160){if(typeof v!=='string')fail(400,'Informe um texto válido.');const s=v.trim();if(s.length<min||s.length>max||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(s))fail(400,`O texto deve ter entre ${min} e ${max} caracteres.`);return s;}
export function integer(v,min=0,max=100000000){if(!Number.isSafeInteger(v)||v<min||v>max)fail(400,`Informe um número inteiro entre ${min} e ${max}.`);return v;}
export function phoneValue(v){let p=String(v||'').replace(/\D/g,'');if(p.length===11)p='55'+p;if(!/^55[1-9]\d9\d{8}$/.test(p))fail(400,'Informe um celular brasileiro com DDD.');return p;}
export function dateValue(v){if(!/^\d{4}-\d{2}-\d{2}$/.test(v||''))fail(400,'Data inválida.');const d=new Date(v+'T12:00:00Z');if(!Number.isFinite(+d)||d.toISOString().slice(0,10)!==v)fail(400,'Data inválida.');return v;}
const localFormatter=new Intl.DateTimeFormat('en-CA',{timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
export function localParts(t=nowSeconds()){const p=localFormatter.formatToParts(new Date(t*1000));const g=k=>p.find(x=>x.type===k).value;return {day:`${g('year')}-${g('month')}-${g('day')}`,minute:Number(g('hour'))*60+Number(g('minute')),time:`${g('hour')}:${g('minute')}`};}
export function zonedEpoch(day,minute){dateValue(day);integer(minute,0,1440);const target=Date.parse(day+'T00:00:00Z')+minute*60000;let guess=target;for(let i=0;i<3;i++){const p=localParts(Math.floor(guess/1000));const asUTC=Date.parse(p.day+'T00:00:00Z')+p.minute*60000;guess+=target-asUTC;}return Math.floor(guess/1000);}
export function addDays(day,n){return new Date(Date.parse(dateValue(day)+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);}
export const weekday=day=>new Date(dateValue(day)+'T12:00:00Z').getUTCDay();
export const intersects=(a,b,c,d)=>a<d&&b>c;
export const commissionSplit=(amount,bps,isOwner=false)=>({barber_cents:isOwner?0:Math.round(amount*bps/10000),house_cents:isOwner?amount:amount-Math.round(amount*bps/10000)});
export function allowedTransition(from,to){return ({booked:['waiting','in_service','cancelled','no_show'],waiting:['in_service','cancelled','no_show'],in_service:['completed','cancelled'],completed:[],cancelled:[],no_show:[]}[from]||[]).includes(to);}
export function monthPeriod(day){return {from:day.slice(0,7)+'-01',to:addDays(new Date(Date.UTC(Number(day.slice(0,4)),Number(day.slice(5,7)),0,12)).toISOString().slice(0,10),1)};}
export function safeURL(s){try{const u=new URL(s);return u.protocol==='https:'?u.href:null;}catch{return null;}}
