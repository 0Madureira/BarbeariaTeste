import {DEFAULT_SETTINGS,ACTIVE,STATUS,ZONE,HttpError,fail,nowSeconds,uid,textValue,integer,phoneValue,dateValue,localParts,zonedEpoch,addDays,weekday,intersects,commissionSplit,allowedTransition} from './domain.mjs';
import {stmt,rows,first,auditStmt,rateLimit,randomToken,digest,secretEqual,passwordHash,passwordMatches,passwordValue,publicUser,createSession,sessionCookie,getSession,requireUser,checkOrigin,checkCSRF,bodyJSON,requestKey,requirePepper} from './auth.mjs';
import {integrationStatus,asaasRequest,createHostedCheckout,reconcileAsaasPayment,enqueueNotification,sendOTP,processNotifications,metaSignatureValid} from './integrations.mjs';
import {baseStatements,seedDemo} from './seed.mjs';
import {ASSET_MAP} from './assets.mjs';

const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...headers}});
const okay=data=>json(data??{ok:true});
async function configuration(env){const s=await first(env,'SELECT value,version FROM settings WHERE id=1');return s?{...DEFAULT_SETTINGS,...JSON.parse(s.value),version:s.version}:{...DEFAULT_SETTINGS,version:0};}
function guard(env,id,sql,...params){return stmt(env,'INSERT INTO guards(id,ok) VALUES(?,CASE WHEN ('+sql+') THEN 1 ELSE 0 END)',id,...params);}
function guardCleanup(env,id){return stmt(env,'DELETE FROM guards WHERE id=?',id);}
function parsePeriod(url,maxDays=93){const today=localParts().day,from=dateValue(url.searchParams.get('from')||today),to=dateValue(url.searchParams.get('to')||addDays(from,1));if(to<=from||Date.parse(to)-Date.parse(from)>maxDays*86400000)fail(400,'Selecione um período válido de até '+maxDays+' dias.');return {from,to,start:zonedEpoch(from,0),end:zonedEpoch(to,0)};}
async function ensureCustomer(env,id){const c=await first(env,"SELECT id,name,phone,role,verified,active FROM users WHERE id=? AND role='customer'",id);if(!c)fail(404,'Cliente não encontrado.');return c;}
function exclusiveAdminRoute(path){return path.startsWith('/api/admin/');}
async function getSchedule(env,barberId,day){const special=await rows(env,'SELECT * FROM special_hours WHERE barber_id=? AND day=? ORDER BY start_minute',barberId,day);return special.length?special:rows(env,'SELECT * FROM weekly_hours WHERE barber_id=? AND weekday=? ORDER BY start_minute',barberId,weekday(day));}
async function getAvailability(env,barberId,serviceId,day,{admin=false,excludeId=null}={}){
  const config=await configuration(env),service=await first(env,'SELECT * FROM services WHERE id=? AND active=1',serviceId);
  const barber=await first(env,'SELECT b.* FROM barbers b JOIN barber_services bs ON bs.barber_id=b.id WHERE b.id=? AND bs.service_id=? AND b.active=1',barberId,serviceId);
  if(!service||!barber||(!barber.online&&!admin))return {slots:[],service,reason:'Este profissional não está disponível para o serviço.'};
  const today=localParts().day;if(day<today||day>addDays(today,config.horizon_days))return {slots:[],service,reason:'A data está fora da janela de agendamento.'};
  const start=zonedEpoch(day,0),end=zonedEpoch(day,1440),schedule=await getSchedule(env,barberId,day);
  const busy=await rows(env,"SELECT starts_at,ends_at FROM appointments WHERE barber_id=? AND status NOT IN('cancelled','no_show') AND starts_at<? AND ends_at>? AND id<>?",barberId,end,start,excludeId||'');
  const blocks=await rows(env,'SELECT starts_at,ends_at FROM blocks WHERE (barber_id=? OR barber_id IS NULL) AND starts_at<? AND ends_at>?',barberId,end,start);
  const slots=[];for(const interval of schedule)for(let minute=interval.start_minute;minute+service.duration_minutes<=interval.end_minute;minute+=config.slot_minutes){const s=zonedEpoch(day,minute),e=s+service.duration_minutes*60;if(s<nowSeconds()+(admin?0:config.minimum_notice_minutes)*60)continue;if([...busy,...blocks].some(b=>intersects(s,e,b.starts_at,b.ends_at)))continue;slots.push({starts_at:s,ends_at:e,time:localParts(s).time,minute});}
  return {slots,service,reason:slots.length?null:schedule.length?'Não há horários livres para este serviço nesta data.':'Rodrigues ainda não abriu a agenda deste dia.'};
}
async function prepareAppointment(env,request,user,b,{reschedule=null}={}){
  const admin=user.role==='admin',customerId=admin?textValue(b.customer_id,1,100):user.id;await ensureCustomer(env,customerId);
  const barberId=textValue(b.barber_id,1,100),serviceId=textValue(b.service_id,1,100),day=dateValue(b.day),minute=integer(b.minute,0,1435);
  const available=await getAvailability(env,barberId,serviceId,day,{admin,excludeId:reschedule?.id});const match=available.slots.find(s=>s.minute===minute);if(!match)fail(409,available.reason||'Este horário acabou de ficar indisponível. Escolha outro.','slot_unavailable');
  const service=available.service,barber=await first(env,'SELECT * FROM barbers WHERE id=?',barberId);
  const sub=await first(env,"SELECT s.* FROM subscriptions s JOIN subscription_services ps ON ps.subscription_id=s.id WHERE s.user_id=? AND s.status IN('active','cancelled') AND s.valid_until>=? AND ps.service_id=? ORDER BY s.valid_until DESC LIMIT 1",customerId,match.ends_at,serviceId);
  const key=requestKey(request,b);const fingerprint=await digest(JSON.stringify({customerId,barberId,serviceId,day,minute,notes:b.notes||''}));
  const a={id:uid(),customer_id:customerId,barber_id:barberId,service_id:serviceId,starts_at:match.starts_at,ends_at:match.ends_at,local_day:day,start_minute:minute,end_minute:minute+service.duration_minutes,service_name:service.name,barber_name:barber.name,price_cents:service.price_cents,duration_minutes:service.duration_minutes,commission_bps:barber.commission_bps,owner_snapshot:barber.is_owner,subscription_id:sub?.id||null,notes:b.notes?textValue(b.notes,0,500):'',admin_override:admin?1:0,request_key:key,request_fingerprint:fingerprint,created_at:nowSeconds(),updated_at:nowSeconds()};
  return a;
}
function appointmentInsert(env,a){const keys=Object.keys(a);return stmt(env,'INSERT INTO appointments('+keys.join(',')+') VALUES('+keys.map(()=>'?').join(',')+')',...keys.map(k=>a[k]));}
async function authorizedAppointment(env,user,id){const a=await first(env,'SELECT * FROM appointments WHERE id=?',id);if(!a||(user.role!=='admin'&&a.customer_id!==user.id))fail(404,'Agendamento não encontrado.');return a;}
async function apiRoute(request,env,ctx){
  const url=new URL(request.url),path=url.pathname,method=request.method;
  if(method==='OPTIONS')return new Response(null,{status:405});
  const isWebhook=path.startsWith('/api/webhooks/');if(!['GET','HEAD'].includes(method)&&!isWebhook)checkOrigin(request);
  if(path==='/api/health')return okay({ok:true,version:'1.0.0',environment:env.DEMO_MODE==='true'?'demonstration':'production',timezone:ZONE});
  if(!env.DB)fail(503,'Banco de dados ainda não configurado.');
  if(path==='/api/public/catalog'&&method==='GET'){
    const config=await configuration(env);const services=await rows(env,'SELECT id,name,description,category,price_cents,duration_minutes,sort_order FROM services WHERE active=1 ORDER BY sort_order,name');
    const barbers=await rows(env,'SELECT id,name,bio,photo_key,online FROM barbers WHERE active=1 ORDER BY is_owner DESC,name');
    const capabilities=await rows(env,'SELECT bs.* FROM barber_services bs JOIN barbers b ON b.id=bs.barber_id WHERE b.active=1');
    const plans=await rows(env,'SELECT * FROM plans WHERE active=1 ORDER BY price_cents');const benefits=await rows(env,'SELECT * FROM plan_services');
    return okay({services,barbers:barbers.map(b=>({...b,photo_url:b.photo_key?'/media/'+encodeURIComponent(b.photo_key):null,service_ids:capabilities.filter(c=>c.barber_id===b.id).map(c=>c.service_id)})),plans:plans.map(p=>({...p,service_ids:benefits.filter(c=>c.plan_id===p.id).map(c=>c.service_id)})),settings:{business_name:config.business_name,address:config.address,phone:config.phone,instagram:config.instagram,minimum_notice_minutes:config.minimum_notice_minutes,horizon_days:config.horizon_days,cancellation_minutes:config.cancellation_minutes,max_future_bookings:config.max_future_bookings,privacy_contact:config.privacy_contact},demo:env.DEMO_MODE==='true',initialized:!!config.version,integrations:{payments:integrationStatus(env).asaas.configured,phone:integrationStatus(env).phone_verification_configured}});
  }
  if(path==='/api/availability'&&method==='GET'){
    const day=dateValue(url.searchParams.get('day'));const user=await getSession(env,request);let excludeId=null;
    if(url.searchParams.get('reschedule_id')){if(!user)fail(401,'Entre na sua conta.');excludeId=(await authorizedAppointment(env,user,url.searchParams.get('reschedule_id'))).id;}
    return okay(await getAvailability(env,textValue(url.searchParams.get('barber_id'),1,100),textValue(url.searchParams.get('service_id'),1,100),day,{admin:user?.role==='admin',excludeId}));
  }
  if(path==='/api/demo/start'&&method==='POST'){
    if(env.DEMO_MODE!=='true'||(!env.LOCAL_DEMO&&!request.headers.get('oai-authenticated-user-id')))fail(403,'A demonstração está disponível apenas no ambiente privado de testes.');
    await rateLimit(env,request,'demo',60);await seedDemo(env);const b=await bodyJSON(request);const u=await first(env,'SELECT * FROM users WHERE id=?',b.role==='customer'?'demo-customer-0':'demo-admin');const session=await createSession(env,u);return json({user:session.user,csrf:session.csrf,demo:true},200,{'set-cookie':session.cookie});
  }
  if(path==='/api/auth/bootstrap'&&method==='POST'){
    await rateLimit(env,request,'bootstrap',3,3600);if(env.DEMO_MODE==='true')fail(403,'Use a entrada de demonstração.');
    if(!env.BOOTSTRAP_TOKEN||!secretEqual(request.headers.get('x-bootstrap-token'),env.BOOTSTRAP_TOKEN))fail(403,'Chave de implantação inválida.');
    if(await first(env,"SELECT id FROM users WHERE role='admin'"))fail(409,'O administrador já foi configurado.');
    const b=await bodyJSON(request),phone=phoneValue(b.phone),name='Rodrigues',hash=await passwordHash(passwordValue(b.password,true),env),now=nowSeconds(),id=uid();
    await env.DB.batch([...(await baseStatements(env)),stmt(env,"INSERT INTO users(id,role,name,phone,password_hash,verified,created_at,updated_at) VALUES(?,'admin',?,?,?,1,?,?)",id,name,phone,hash,now,now),auditStmt(env,null,'system.bootstrap',id)]);return json({ok:true,message:'Administrador criado. Remova BOOTSTRAP_TOKEN e entre com sua senha.'},201);
  }
  if(path==='/api/auth/me'&&method==='GET'){const u=await getSession(env,request);return okay({user:u?publicUser(u):null,csrf:u?.csrf||null,demo:env.DEMO_MODE==='true'});}
  if(path==='/api/auth/login'&&method==='POST'){
    const b=await bodyJSON(request);await rateLimit(env,request,'login-ip',25);const phone=phoneValue(b.phone);await rateLimit(env,request,'login-phone',8,900,phone);
    const u=await first(env,'SELECT * FROM users WHERE phone=? AND active=1',phone);
    // Use real scrypt work even for missing users to reduce enumeration by timing.
    const hash=u?.password_hash||'scrypt$32768$8$3$0000000000000000000000000000000000000000000000000000000000000000$0000000000000000000000000000000000000000000000000000000000000000';
    if(!await passwordMatches(b.password,hash,env)||!u||!u.verified)fail(401,'Telefone ou senha inválidos.','invalid_credentials');
    const session=await createSession(env,u);return json({user:session.user,csrf:session.csrf},200,{'set-cookie':session.cookie});
  }
  if(path==='/api/auth/logout'&&method==='POST'){const u=await requireUser(env,request);await stmt(env,'DELETE FROM sessions WHERE token_hash=?',u.token_hash).run();return json({ok:true},200,{'set-cookie':sessionCookie('',0)});}
  if(path==='/api/auth/register'&&method==='POST'){
    const b=await bodyJSON(request);await rateLimit(env,request,'register',5,3600);const phone=phoneValue(b.phone);await rateLimit(env,request,'otp-phone',3,3600,phone);
    if(env.DEMO_MODE!=='true'&&!integrationStatus(env).phone_verification_configured)fail(503,'O cadastro será liberado após a configuração da verificação oficial de telefone.','phone_provider_unconfigured');
    if(b.accept_terms!==true)fail(400,'Aceite os termos e a política de privacidade.');
    const name=textValue(b.name,2,100),hash=await passwordHash(passwordValue(b.password),env),now=nowSeconds();
    const exists=await first(env,'SELECT id,verified,role FROM users WHERE phone=?',phone);if(exists&&(exists.verified||exists.role==='admin'))fail(409,'Não foi possível cadastrar. Se já tem conta, entre ou recupere o acesso.');
    const id=exists?.id||uid();const saved=await env.DB.batch([stmt(env,"UPDATE challenges SET consumed=1 WHERE phone=? AND purpose='verify'",phone),stmt(env,"INSERT INTO users(id,role,name,phone,password_hash,verified,consent_service,consent_marketing,consent_at,created_at,updated_at) VALUES(?,'customer',?,?,?,0,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,password_hash=excluded.password_hash,consent_service=excluded.consent_service,consent_marketing=excluded.consent_marketing,consent_at=excluded.consent_at,updated_at=excluded.updated_at WHERE users.verified=0",id,name,phone,hash,b.consent_service===true?1:0,b.consent_marketing===true?1:0,now,now,now)]);if(saved[1].meta.changes===0)fail(409,'A conta já foi verificada. Entre ou recupere o acesso.');
    return issueChallenge(env,phone,'verify');
  }
  if(path==='/api/auth/recover'&&method==='POST'){
    const b=await bodyJSON(request);const phone=phoneValue(b.phone);await rateLimit(env,request,'recover',5,3600);await rateLimit(env,request,'otp-phone',3,3600,phone);
    const u=await first(env,'SELECT id FROM users WHERE phone=? AND active=1 AND verified=1',phone);if(!u)return okay({message:'Se houver uma conta, enviaremos um código.',challenge_id:uid()});return issueChallenge(env,phone,'recover');
  }
  if(path==='/api/auth/verify'&&method==='POST'){
    const b=await bodyJSON(request);await rateLimit(env,request,'verify',15);const challenge=await first(env,'SELECT * FROM challenges WHERE id=?',textValue(b.challenge_id,1,100));
    if(!challenge||challenge.consumed||challenge.expires_at<nowSeconds()||challenge.attempts>=5)fail(400,'Código inválido ou expirado. Solicite outro.');
    await stmt(env,'UPDATE challenges SET attempts=attempts+1 WHERE id=?',challenge.id).run();
    if(!secretEqual(challenge.code_hash,await digest(challenge.id+':'+String(b.code)+':'+requirePepper(env))))fail(400,'Código inválido ou expirado.');
    const u=await first(env,'SELECT * FROM users WHERE phone=?',challenge.phone);const g=uid();const changes=[guard(env,g,'SELECT EXISTS(SELECT 1 FROM challenges WHERE id=? AND consumed=0 AND attempts<=5 AND expires_at>?)',challenge.id,nowSeconds()),stmt(env,'UPDATE challenges SET consumed=1 WHERE id=?',challenge.id),stmt(env,'UPDATE users SET verified=1,updated_at=? WHERE id=?',nowSeconds(),u.id)];
    if(challenge.purpose==='recover'){const hash=await passwordHash(passwordValue(b.new_password,u.role==='admin'),env);changes.push(stmt(env,'UPDATE users SET password_hash=? WHERE id=?',hash,u.id),stmt(env,'DELETE FROM sessions WHERE user_id=?',u.id));}
    changes.push(guardCleanup(env,g));await env.DB.batch(changes);u.verified=1;const session=await createSession(env,u);return json({user:session.user,csrf:session.csrf},200,{'set-cookie':session.cookie});
  }
  if(path==='/api/webhooks/asaas'&&method==='POST'){
    if(!env.ASAAS_WEBHOOK_TOKEN||!secretEqual(request.headers.get('asaas-access-token'),env.ASAAS_WEBHOOK_TOKEN))fail(401,'Evento não autenticado.');
    const b=await bodyJSON(request,262144);const eventId=textValue(b.id,1,200),event=textValue(b.event,1,100);if(await first(env,'SELECT id FROM webhook_events WHERE id=?',eventId))return okay({duplicate:true});
    if(b.payment?.id)return okay(await reconcileAsaasPayment(env,b.payment.id,eventId,event));
    if(b.subscription?.id){const remote=await asaasRequest(env,'/subscriptions/'+encodeURIComponent(b.subscription.id));const sub=await first(env,'SELECT id FROM subscriptions WHERE id=? OR provider_id=?',remote.externalReference||'',remote.id);if(sub){await env.DB.batch([stmt(env,'INSERT INTO webhook_events(id,provider,event_type,received_at) VALUES(?,?,?,?)',eventId,'asaas',event,nowSeconds()),stmt(env,'UPDATE subscriptions SET provider_id=? WHERE id=?',remote.id,sub.id)]);return okay({processed:true});}}
    return okay({ignored:true});
  }
  if(path==='/api/webhooks/meta'&&method==='GET'){
    if(env.META_WEBHOOK_VERIFY_TOKEN&&secretEqual(url.searchParams.get('hub.verify_token'),env.META_WEBHOOK_VERIFY_TOKEN)&&url.searchParams.get('hub.mode')==='subscribe')return new Response(url.searchParams.get('hub.challenge'));fail(403,'Verificação inválida.');
  }
  if(path==='/api/webhooks/meta'&&method==='POST'){
    if(Number(request.headers.get('content-length'))>262144)fail(413,'Evento muito grande.');const raw=await request.text();if(raw.length>262144)fail(413,'Evento muito grande.');if(!await metaSignatureValid(env,request,raw))fail(401,'Assinatura do evento inválida.');let b;try{b=JSON.parse(raw);}catch{fail(400,'Evento inválido.');}
    for(const entry of b.entry||[])for(const change of entry.changes||[])for(const status of change.value?.statuses||[]){if(['delivered','read'].includes(status.status))await stmt(env,"UPDATE notifications SET status='delivered',updated_at=? WHERE provider_id=?",nowSeconds(),status.id).run();else if(status.status==='failed')await stmt(env,"UPDATE notifications SET status='failed',last_error='Falha informada pela Meta.',updated_at=?,next_attempt_at=? WHERE provider_id=? AND status<>'delivered'",nowSeconds(),nowSeconds()+600,status.id).run();}
    return okay({received:true});
  }
  const user=await requireUser(env,request,exclusiveAdminRoute(path));
  if(path==='/api/me/profile'&&method==='PATCH'){
    const b=await bodyJSON(request);if(b.phone&&phoneValue(b.phone)!==user.phone)fail(400,'Para trocar de telefone, confirme a titularidade pelo atendimento do Rodrigues.');
    const name=textValue(b.name,2,100);await env.DB.batch([stmt(env,'UPDATE users SET name=?,consent_service=?,consent_marketing=?,consent_at=?,updated_at=? WHERE id=?',name,b.consent_service===true?1:0,b.consent_marketing===true?1:0,nowSeconds(),nowSeconds(),user.id),auditStmt(env,user,'profile.update',user.id)]);return okay({user:publicUser({...user,name,consent_service:b.consent_service,consent_marketing:b.consent_marketing})});
  }
  if(path==='/api/me/password'&&method==='POST'){
    const b=await bodyJSON(request);await rateLimit(env,request,'password-change',5);if(!await passwordMatches(b.current_password,user.password_hash,env))fail(401,'Senha atual inválida.');const hash=await passwordHash(passwordValue(b.new_password,user.role==='admin'),env);await env.DB.batch([stmt(env,'UPDATE users SET password_hash=?,updated_at=? WHERE id=?',hash,nowSeconds(),user.id),stmt(env,'DELETE FROM sessions WHERE user_id=?',user.id),auditStmt(env,user,'password.changed',user.id)]);return json({ok:true,login_required:true},200,{'set-cookie':sessionCookie('',0)});
  }
  if(path==='/api/me/export'&&method==='GET'){
    return okay({profile:publicUser(user),appointments:await rows(env,'SELECT id,service_name,barber_name,starts_at,ends_at,status,price_cents,charged_cents,subscription_id FROM appointments WHERE customer_id=? ORDER BY starts_at DESC',user.id),subscriptions:await rows(env,'SELECT id,plan_name,price_cents,status,valid_until,cancel_at_end,provider_mode FROM subscriptions WHERE user_id=?',user.id),consent:{service:!!user.consent_service,marketing:!!user.consent_marketing,recorded_at:user.consent_at}});
  }
  if(path==='/api/me/privacy-request'&&method==='POST'){const b=await bodyJSON(request);const type=['access','correction','deletion','portability'].includes(b.type)?b.type:'access';await auditStmt(env,user,'privacy.request',user.id,{type}).run();return okay({message:'Solicitação registrada. Rodrigues deverá analisar a identificação e os prazos de retenção aplicáveis.'});}
  if(path==='/api/me/appointments'&&method==='GET')return okay({appointments:await rows(env,'SELECT a.*,COALESCE((SELECT SUM(amount_cents) FROM receipts r WHERE r.appointment_id=a.id),0) received_cents FROM appointments a WHERE customer_id=? ORDER BY starts_at DESC LIMIT 100',user.id)});
  if(path==='/api/appointments'&&method==='POST'){
    const b=await bodyJSON(request),customerId=user.role==='admin'?b.customer_id:user.id,key=requestKey(request,b);const old=await first(env,'SELECT * FROM appointments WHERE customer_id=? AND request_key=?',customerId,key);
    if(old){const fingerprint=await digest(JSON.stringify({customerId,barberId:b.barber_id,serviceId:b.service_id,day:b.day,minute:b.minute,notes:b.notes||''}));if(old.request_fingerprint!==fingerprint)fail(409,'A chave já foi usada em outra operação.');return okay({appointment:old,idempotent:true});}
    const a=await prepareAppointment(env,request,user,b);await env.DB.batch([appointmentInsert(env,a),auditStmt(env,user,'appointment.create',a.id,{customer_id:a.customer_id,barber_id:a.barber_id,subscription:!!a.subscription_id})]);await enqueueNotification(env,a.customer_id,'booking_confirmation',a.id,{parameters:[a.service_name,a.local_day,localParts(a.starts_at).time,a.barber_name]});return json({appointment:{...a,status:'booked',version:1},message:'Agendamento confirmado automaticamente.'},201);
  }
  const cancel=path.match(/^\/api\/appointments\/([^/]+)\/cancel$/);
  if(cancel&&method==='POST'){
    const a=await authorizedAppointment(env,user,cancel[1]),b=await bodyJSON(request),c=await configuration(env);
    if(!ACTIVE.includes(a.status))fail(409,'Este agendamento não pode mais ser cancelado.');if(user.role!=='admin'&&a.starts_at-nowSeconds()<c.cancellation_minutes*60)fail(409,'O prazo de cancelamento terminou. Fale com Rodrigues.');
    const g=uid();await env.DB.batch([guard(env,g,'SELECT EXISTS(SELECT 1 FROM appointments WHERE id=? AND version=? AND status=?)',a.id,integer(b.version,1),a.status),stmt(env,"UPDATE appointments SET status='cancelled',updated_at=?,version=version+1 WHERE id=?",nowSeconds(),a.id),stmt(env,"UPDATE notifications SET status='cancelled' WHERE entity_id=? AND status IN('pending','failed','unconfigured')",a.id),auditStmt(env,user,'appointment.cancel',a.id,{reason:b.reason?textValue(b.reason,1,500):''}),guardCleanup(env,g)]);await enqueueNotification(env,a.customer_id,'booking_cancelled',a.id,{parameters:[a.service_name,a.local_day,localParts(a.starts_at).time]});return okay();
  }
  const reschedule=path.match(/^\/api\/appointments\/([^/]+)\/reschedule$/);
  if(reschedule&&method==='POST'){
    const a=await authorizedAppointment(env,user,reschedule[1]),b=await bodyJSON(request),c=await configuration(env);
    if(a.status!=='booked')fail(409,'Só é possível reagendar um horário ainda agendado.');if(user.role!=='admin'&&a.starts_at-nowSeconds()<c.cancellation_minutes*60)fail(409,'O prazo de reagendamento terminou. Fale com Rodrigues.');
    const previous=await first(env,'SELECT * FROM appointments WHERE customer_id=? AND request_key=?',a.customer_id,requestKey(request,b));if(previous)return okay({appointment:previous,idempotent:true});
    const next=await prepareAppointment(env,request,user,{...b,customer_id:a.customer_id},{reschedule:a});const g=uid();await env.DB.batch([guard(env,g,"SELECT EXISTS(SELECT 1 FROM appointments WHERE id=? AND version=? AND status='booked')",a.id,integer(b.version,1)),stmt(env,"UPDATE appointments SET status='cancelled',updated_at=?,version=version+1 WHERE id=?",nowSeconds(),a.id),appointmentInsert(env,next),auditStmt(env,user,'appointment.reschedule',a.id,{new_id:next.id}),stmt(env,"UPDATE notifications SET status='cancelled' WHERE entity_id=? AND status IN('pending','failed','unconfigured')",a.id),guardCleanup(env,g)]);await enqueueNotification(env,next.customer_id,'booking_rescheduled',next.id,{parameters:[next.service_name,next.local_day,localParts(next.starts_at).time,next.barber_name]});return okay({appointment:{...next,status:'booked',version:1}});
  }
  if(path==='/api/me/subscriptions'&&method==='GET'){return okay({subscriptions:await rows(env,'SELECT * FROM subscriptions WHERE user_id=? ORDER BY created_at DESC',user.id),payments:await rows(env,'SELECT p.* FROM subscription_payments p JOIN subscriptions s ON s.id=p.subscription_id WHERE s.user_id=? ORDER BY p.paid_at DESC',user.id)});}
  if(path==='/api/me/subscriptions'&&method==='POST')return createSubscription(request,env,user,await bodyJSON(request));
  const subCancel=path.match(/^\/api\/me\/subscriptions\/([^/]+)\/cancel$/);
  if(subCancel&&method==='POST')return cancelSubscription(request,env,user,subCancel[1]);
  if(user.role!=='admin')fail(404,'Recurso não encontrado.');
  return adminRoute(request,env,ctx,user,url,path,method);
}

async function issueChallenge(env,phone,purpose){const id=uid(),code=String(crypto.getRandomValues(new Uint32Array(1))[0]%1000000).padStart(6,'0');const hash=await digest(id+':'+code+':'+requirePepper(env));if(env.DEMO_MODE!=='true')await sendOTP(env,phone,code);await stmt(env,'INSERT INTO challenges(id,phone,purpose,code_hash,expires_at) VALUES(?,?,?,?,?)',id,phone,purpose,hash,nowSeconds()+600).run();return okay({challenge_id:id,message:env.DEMO_MODE==='true'?'Código de teste: nenhum WhatsApp foi enviado.':'Se houver uma conta, o código será enviado pelo canal oficial.',...(env.DEMO_MODE==='true'?{demo_code:code}:{})});}

async function adminRoute(request,env,ctx,user,url,path,method){
  if(path==='/api/admin/overview'&&method==='GET'){
    const day=dateValue(url.searchParams.get('day')||localParts().day),start=zonedEpoch(day,0),end=zonedEpoch(day,1440),config=await configuration(env);
    const counts=await first(env,"SELECT COUNT(*) scheduled,SUM(status='completed') completed,SUM(status='waiting') waiting,SUM(status='in_service') in_service,SUM(status='cancelled') cancelled,SUM(status='no_show') no_show FROM appointments WHERE local_day=?",day);
    const financial=await first(env,'SELECT COALESCE(SUM(amount_cents),0) received_cents FROM receipts WHERE received_at>=? AND received_at<?',start,end);
    const inactive=await first(env,"SELECT COUNT(*) total FROM (SELECT u.id,MAX(a.completed_at) last_visit FROM users u JOIN appointments a ON a.customer_id=u.id AND a.status='completed' WHERE u.role='customer' GROUP BY u.id HAVING last_visit<?)",nowSeconds()-config.inactive_days*86400);
    const balance=await first(env,'SELECT COALESCE(SUM(c.barber_cents-COALESCE((SELECT SUM(pa.amount_cents) FROM payout_allocation_balance pa WHERE pa.commission_id=c.id),0)-COALESCE((SELECT SUM(r.barber_adjustment_cents) FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.appointment_id=c.appointment_id),0)),0) cents FROM commissions c');
    const appointments=await rows(env,'SELECT a.*,u.name customer_name,u.phone customer_phone FROM appointments a JOIN users u ON u.id=a.customer_id WHERE a.local_day=? ORDER BY a.starts_at',day);
    const latest=await rows(env,"SELECT a.id,a.service_name,a.barber_name,a.completed_at,u.name customer_name FROM appointments a JOIN users u ON u.id=a.customer_id WHERE a.status='completed' ORDER BY a.completed_at DESC LIMIT 6");
    const inactiveList=await rows(env,"SELECT u.id,u.name,MAX(a.completed_at) last_visit,CAST((?-MAX(a.completed_at))/86400 AS INTEGER) days_away FROM users u JOIN appointments a ON a.customer_id=u.id AND a.status='completed' GROUP BY u.id HAVING last_visit<? ORDER BY last_visit LIMIT 5",nowSeconds(),nowSeconds()-config.inactive_days*86400);
    const subscriptions=await first(env,"SELECT COUNT(*) active FROM subscriptions WHERE status IN('active','cancelled') AND valid_until>?",nowSeconds());
    const refunds=await first(env,'SELECT COALESCE(SUM(amount_cents),0) cents FROM refunds WHERE created_at>=? AND created_at<?',start,end);
    return okay({day,counts,financial:{...financial,refunds_cents:refunds.cents,net_received_cents:financial.received_cents-refunds.cents,commission_pending_cents:balance.cents},inactive_clients:inactive.total,active_subscriptions:subscriptions.active,appointments,latest,inactive:inactiveList,integrations:integrationStatus(env)});
  }
  if(path==='/api/admin/appointments'&&method==='GET'){
    const p=parsePeriod(url,45),barber=url.searchParams.get('barber_id')||'';
    const appointments=await rows(env,'SELECT a.*,u.name customer_name,u.phone customer_phone,COALESCE((SELECT SUM(amount_cents) FROM receipts r WHERE r.appointment_id=a.id),0) received_cents FROM appointments a JOIN users u ON u.id=a.customer_id WHERE a.starts_at>=? AND a.starts_at<? AND (?=\'\' OR a.barber_id=?) ORDER BY a.starts_at LIMIT 1001',p.start,p.end,barber,barber);
    return okay({appointments:appointments.slice(0,1000),truncated:appointments.length>1000,blocks:await rows(env,'SELECT * FROM blocks WHERE starts_at<? AND ends_at>?',p.end,p.start),weekly_hours:await rows(env,'SELECT * FROM weekly_hours'),special_hours:await rows(env,'SELECT * FROM special_hours WHERE day>=? AND day<?',p.from,p.to)});
  }
  const statusMatch=path.match(/^\/api\/admin\/appointments\/([^/]+)\/status$/);
  if(statusMatch&&method==='POST'){
    const a=await authorizedAppointment(env,user,statusMatch[1]),b=await bodyJSON(request),to=textValue(b.status,1,30);if(!allowedTransition(a.status,to))fail(409,'Esta mudança de status não é permitida.');
    const completed=to==='completed',charged=completed?(a.subscription_id?0:integer(b.charged_cents,0,a.price_cents)):null;
    if(completed&&a.subscription_id&&!await first(env,"SELECT id FROM subscriptions WHERE id=? AND status IN('active','cancelled') AND valid_until>=?",a.subscription_id,a.ends_at))fail(409,'O benefício desta assinatura deixou de ser válido. Confira o pagamento ou converta este atendimento para avulso antes de concluir.','subscription_inactive');
    if(completed&&a.starts_at>nowSeconds()+300)fail(409,'Aguarde o início do horário para concluir o atendimento.');
    if(completed&&!a.subscription_id&&charged!==a.price_cents&&!b.discount_reason)fail(400,'Informe o motivo do desconto.');
    const key=completed&&b.received_cents>0?requestKey(request,b):null,g=uid();const q=[guard(env,g,'SELECT EXISTS(SELECT 1 FROM appointments WHERE id=? AND version=? AND status=?)',a.id,integer(b.version,1),a.status),stmt(env,'UPDATE appointments SET status=?,charged_cents=CASE WHEN ? THEN ? ELSE charged_cents END,discount_reason=?,checked_in_at=CASE WHEN ? AND checked_in_at IS NULL THEN ? ELSE checked_in_at END,completed_at=CASE WHEN ? THEN ? ELSE completed_at END,updated_at=?,version=version+1 WHERE id=?',to,completed?1:0,charged,b.discount_reason||null,['waiting','in_service'].includes(to)?1:0,nowSeconds(),completed?1:0,nowSeconds(),nowSeconds(),a.id)];
    if(key){const methods=(await configuration(env)).payment_methods;if(!methods.includes(b.method))fail(400,'Forma de pagamento inválida.');q.push(stmt(env,'INSERT INTO receipts(id,appointment_id,amount_cents,method,received_at,request_key,created_by) VALUES(?,?,?,?,?,?,?)',uid(),a.id,integer(b.received_cents,1,charged),b.method,nowSeconds(),key,user.id));}
    if(completed&&a.subscription_id){q.unshift(guard(env,g+'-sub',"SELECT EXISTS(SELECT 1 FROM subscriptions WHERE id=? AND status IN('active','cancelled') AND valid_until>=?)",a.subscription_id,a.ends_at));q.push(guardCleanup(env,g+'-sub'));}
    q.push(auditStmt(env,user,'appointment.status',a.id,{from:a.status,to,charged_cents:charged}),guardCleanup(env,g));await env.DB.batch(q);return okay({appointment:await first(env,'SELECT * FROM appointments WHERE id=?',a.id),commission:completed?await first(env,'SELECT * FROM commissions WHERE appointment_id=?',a.id):null});
  }
  const billing=path.match(/^\/api\/admin\/appointments\/([^/]+)\/billing$/);
  if(billing&&method==='POST'){
    const a=await authorizedAppointment(env,user,billing[1]),b=await bodyJSON(request);if(!a.subscription_id||!ACTIVE.includes(a.status))fail(409,'Este atendimento não permite conversão de cobrança.');
    if(await first(env,"SELECT id FROM subscriptions WHERE id=? AND status IN('active','cancelled') AND valid_until>=?",a.subscription_id,a.ends_at))fail(409,'O benefício está válido. O serviço coberto deve permanecer sem cobrança avulsa.');
    const reason=textValue(b.reason,5,500),g=uid();await env.DB.batch([guard(env,g,'SELECT EXISTS(SELECT 1 FROM appointments WHERE id=? AND version=? AND subscription_id IS NOT NULL)',a.id,integer(b.version,1)),stmt(env,'UPDATE appointments SET subscription_id=NULL,version=version+1,updated_at=? WHERE id=?',nowSeconds(),a.id),auditStmt(env,user,'appointment.billing_to_single',a.id,{old_subscription_id:a.subscription_id,reason}),guardCleanup(env,g)]);return okay({appointment:await first(env,'SELECT * FROM appointments WHERE id=?',a.id)});
  }
  if(path==='/api/admin/clients'&&method==='GET'){
    const search=(url.searchParams.get('q')||'').slice(0,100),days=Number(url.searchParams.get('inactive_days')||0);if(![0,30,60,90,180].includes(days))integer(days,1,3650);
    return okay({clients:await rows(env,"SELECT u.id,u.name,u.phone,u.verified,u.active,u.created_at,COUNT(a.id) visits,MAX(a.completed_at) last_visit,COALESCE(SUM(a.charged_cents),0) charged_cents,(SELECT COUNT(*) FROM appointments f WHERE f.customer_id=u.id AND f.status IN('booked','waiting','in_service') AND f.starts_at>?) future_bookings,(SELECT status FROM subscriptions s WHERE s.user_id=u.id ORDER BY s.created_at DESC LIMIT 1) subscription_status FROM users u LEFT JOIN appointments a ON a.customer_id=u.id AND a.status='completed' WHERE u.role='customer' AND (u.name LIKE ? OR u.phone LIKE ?) GROUP BY u.id HAVING (?=0 OR (last_visit IS NOT NULL AND last_visit<?)) ORDER BY u.name LIMIT 300",nowSeconds(),'%'+search+'%','%'+search.replace(/\D/g,'')+'%',days,nowSeconds()-days*86400)});
  }
  if(path==='/api/admin/clients'&&method==='POST'){
    const b=await bodyJSON(request),id=uid(),name=textValue(b.name,2,100),phone=phoneValue(b.phone),now=nowSeconds();
    await env.DB.batch([stmt(env,"INSERT INTO users(id,role,name,phone,verified,created_at,updated_at) VALUES(?,'customer',?,?,0,?,?)",id,name,phone,now,now),auditStmt(env,user,'client.create',id,{verification_pending:true})]);return json({id,message:'Cadastro criado. O cliente deve criar sua senha e verificar o telefone no site antes de agendar.'},201);
  }
  const client=path.match(/^\/api\/admin\/clients\/([^/]+)$/);
  if(client&&method==='GET'){const c=await ensureCustomer(env,client[1]);return okay({client:c,appointments:await rows(env,'SELECT * FROM appointments WHERE customer_id=? ORDER BY starts_at DESC LIMIT 200',c.id),subscriptions:await rows(env,'SELECT * FROM subscriptions WHERE user_id=? ORDER BY created_at DESC',c.id),receipts:await rows(env,'SELECT r.* FROM receipts r JOIN appointments a ON a.id=r.appointment_id WHERE a.customer_id=? ORDER BY r.received_at DESC',c.id)});}
  if(path==='/api/admin/catalog'&&method==='GET')return okay({services:await rows(env,'SELECT * FROM services ORDER BY sort_order,name'),barbers:await rows(env,'SELECT * FROM barbers ORDER BY is_owner DESC,name'),barber_services:await rows(env,'SELECT * FROM barber_services'),plans:await rows(env,'SELECT * FROM plans ORDER BY price_cents'),plan_services:await rows(env,'SELECT * FROM plan_services')});
  if(path==='/api/admin/services'&&method==='POST')return saveService(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/barbers'&&method==='POST')return saveBarber(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/plans'&&method==='POST')return savePlan(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/schedule'&&method==='GET'){return okay({weekly:await rows(env,'SELECT * FROM weekly_hours ORDER BY weekday,start_minute'),special:await rows(env,'SELECT * FROM special_hours WHERE day>=? ORDER BY day,start_minute',localParts().day),blocks:await rows(env,'SELECT * FROM blocks WHERE ends_at>? ORDER BY starts_at',nowSeconds())});}
  if(path==='/api/admin/schedule'&&method==='POST')return saveSchedule(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/blocks'&&method==='POST'){
    const b=await bodyJSON(request);const start=integer(b.starts_at,nowSeconds()-300,nowSeconds()+366*86400),end=integer(b.ends_at,start+60,nowSeconds()+366*86400);const id=uid();await env.DB.batch([stmt(env,'INSERT INTO blocks(id,barber_id,starts_at,ends_at,reason,created_by) VALUES(?,?,?,?,?,?)',id,b.barber_id||null,start,end,textValue(b.reason,2,200),user.id),auditStmt(env,user,'schedule.block',id,{starts_at:start,ends_at:end,barber_id:b.barber_id||null})]);return json({id},201);
  }
  const blockMatch=path.match(/^\/api\/admin\/blocks\/([^/]+)$/);if(blockMatch&&method==='DELETE'){await env.DB.batch([stmt(env,'DELETE FROM blocks WHERE id=?',blockMatch[1]),auditStmt(env,user,'schedule.unblock',blockMatch[1])]);return okay();}
  if(path==='/api/admin/settings'&&method==='GET')return okay({settings:await configuration(env),integrations:integrationStatus(env)});
  if(path==='/api/admin/settings'&&method==='PATCH')return saveSettings(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/finance'&&method==='GET')return financialReport(env,url);
  if(path==='/api/admin/receipts'&&method==='POST')return addReceipt(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/payouts'&&method==='POST')return addPayout(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/payout-returns'&&method==='POST')return addPayoutReturn(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/expenses'&&method==='POST')return addExpense(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/refunds'&&method==='POST')return addRefund(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/cash'&&method==='GET')return okay({sessions:await rows(env,'SELECT * FROM cash_sessions ORDER BY day DESC LIMIT 90')});
  if(path==='/api/admin/cash'&&method==='POST')return manageCash(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/reports'&&method==='GET')return reports(env,url);
  if(path==='/api/admin/export'&&method==='GET')return exportReport(env,url);
  if(path==='/api/admin/subscriptions'&&method==='GET')return okay({subscriptions:await rows(env,'SELECT s.*,u.name customer_name,u.phone FROM subscriptions s JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC LIMIT 500'),payments:await rows(env,'SELECT * FROM subscription_payments ORDER BY paid_at DESC LIMIT 500'),usage:await rows(env,"SELECT a.subscription_id,COUNT(*) visits FROM appointments a WHERE a.status='completed' AND a.subscription_id IS NOT NULL GROUP BY a.subscription_id")});
  if(path==='/api/admin/subscriptions/demo-payment'&&method==='POST')return demoSubscriptionPayment(request,env,user,await bodyJSON(request));
  if(path==='/api/admin/subscriptions/reconcile'&&method==='POST'){
    const b=await bodyJSON(request);const sub=await first(env,'SELECT * FROM subscriptions WHERE id=?',b.subscription_id);if(!sub)fail(404,'Assinatura não encontrada.');if(sub.provider_mode==='demo')fail(400,'Use a confirmação demonstrativa.');const params=new URLSearchParams(sub.provider_id?{subscription:sub.provider_id}:{checkoutSession:sub.checkout_id});const result=await asaasRequest(env,'/payments?'+params+'&limit=100');for(const pay of result.data||[])await reconcileAsaasPayment(env,pay.id,'reconcile-'+pay.id+'-'+uid(),'RECONCILIATION');return okay({processed:result.data?.length||0});
  }
  if(path==='/api/admin/notifications'&&method==='GET')return okay({notifications:await rows(env,'SELECT n.id,n.kind,n.entity_id,n.status,n.attempts,n.provider_id,n.updated_at,n.last_error,u.name customer_name,u.phone FROM notifications n JOIN users u ON u.id=n.user_id ORDER BY n.updated_at DESC LIMIT 150'),integrations:integrationStatus(env)});
  if(path==='/api/admin/notifications/process'&&method==='POST')return okay(await scheduledWork(env));
  if(path==='/api/admin/audit'&&method==='GET'){
    const cursor=integer(Number(url.searchParams.get('before')||nowSeconds()+1),0,9999999999);return okay({logs:await rows(env,'SELECT a.*,u.name actor_name FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id WHERE a.created_at<? ORDER BY a.created_at DESC,a.id LIMIT 100',cursor)});
  }
  if(path==='/api/admin/uploads'&&method==='POST')return uploadFile(request,env,user,url);
  fail(404,'Recurso não encontrado.');
}

async function saveService(request,env,user,b){
  const id=b.id?textValue(b.id,1,100):uid(),old=await first(env,'SELECT * FROM services WHERE id=?',id),name=textValue(b.name,2,100),description=textValue(b.description||'',0,500),category=textValue(b.category||'servicos',2,50),price=integer(b.price_cents,0,1000000),duration=integer(b.duration_minutes,5,240);if(duration%5)fail(400,'A duração deve ser múltipla de 5 minutos.');
  const g=uid(),q=[];if(old)q.push(guard(env,g,'SELECT EXISTS(SELECT 1 FROM services WHERE id=? AND version=?)',id,integer(b.version,1)));
  q.push(stmt(env,'INSERT INTO services(id,name,description,category,price_cents,duration_minutes,active,sort_order) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,description=excluded.description,category=excluded.category,price_cents=excluded.price_cents,duration_minutes=excluded.duration_minutes,active=excluded.active,sort_order=excluded.sort_order,version=services.version+1',id,name,description,category,price,duration,b.active===false?0:1,integer(b.sort_order||0,0,999)),auditStmt(env,user,'service.save',id,{name,price_cents:price,duration_minutes:duration,active:b.active!==false}));if(old)q.push(guardCleanup(env,g));await env.DB.batch(q);return okay({service:await first(env,'SELECT * FROM services WHERE id=?',id)});
}
async function validServices(env,ids){if(!Array.isArray(ids)||!ids.length||ids.length>50)fail(400,'Selecione ao menos um serviço.');const unique=[...new Set(ids)];for(const id of unique)if(!await first(env,'SELECT id FROM services WHERE id=?',id))fail(400,'Serviço inválido.');return unique;}
async function saveBarber(request,env,user,b){
  const id=b.id?textValue(b.id,1,100):uid(),old=await first(env,'SELECT * FROM barbers WHERE id=?',id);const services=await validServices(env,b.service_ids),name=textValue(b.name,2,100),bio=textValue(b.bio||'',0,600),bps=old?.is_owner?0:integer(b.commission_bps??4000,0,10000);const photo=b.photo_key||null;
  if(photo&&!await first(env,"SELECT id FROM uploads WHERE object_key=? AND purpose='barber'",photo))fail(400,'Envie uma foto válida antes de associá-la.');
  if(old?.is_owner&&b.active===false)fail(400,'O perfil de Rodrigues deve permanecer ativo. Desative apenas o agendamento online.');
  const g=uid(),q=[];if(old)q.push(guard(env,g,'SELECT EXISTS(SELECT 1 FROM barbers WHERE id=? AND version=?)',id,integer(b.version,1)));
  q.push(stmt(env,'INSERT INTO barbers(id,name,bio,photo_key,active,online,commission_bps) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,bio=excluded.bio,photo_key=excluded.photo_key,active=excluded.active,online=excluded.online,commission_bps=excluded.commission_bps,version=barbers.version+1',id,name,bio,photo,b.active===false?0:1,b.online===true?1:0,bps),stmt(env,'DELETE FROM barber_services WHERE barber_id=?',id),...services.map(s=>stmt(env,'INSERT INTO barber_services(barber_id,service_id) VALUES(?,?)',id,s)),auditStmt(env,user,'barber.save',id,{name,active:b.active!==false,commission_bps:bps}));if(old)q.push(guardCleanup(env,g));await env.DB.batch(q);
  return okay({barber:await first(env,'SELECT * FROM barbers WHERE id=?',id),future_bookings:await rows(env,"SELECT id,starts_at,service_name FROM appointments WHERE barber_id=? AND starts_at>? AND status IN('booked','waiting','in_service') ORDER BY starts_at",id,nowSeconds()),message:b.active===false?'Profissional desativado. Remarque ou cancele os agendamentos futuros listados.':null});
}
async function savePlan(request,env,user,b){
  const id=b.id?textValue(b.id,1,100):uid(),old=await first(env,'SELECT * FROM plans WHERE id=?',id),serviceIds=await validServices(env,b.service_ids),name=textValue(b.name,2,100),price=integer(b.price_cents,100,1000000),g=uid();
  const q=[];if(old)q.push(guard(env,g,'SELECT EXISTS(SELECT 1 FROM plans WHERE id=? AND version=?)',id,integer(b.version,1)));
  q.push(stmt(env,'INSERT INTO plans(id,name,price_cents,active,for_sale,provisional) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,price_cents=excluded.price_cents,active=excluded.active,for_sale=excluded.for_sale,provisional=excluded.provisional,version=plans.version+1',id,name,price,b.active===false?0:1,b.for_sale===true?1:0,b.provisional===false?0:1),stmt(env,'DELETE FROM plan_services WHERE plan_id=?',id),...serviceIds.map(s=>stmt(env,'INSERT INTO plan_services(plan_id,service_id) VALUES(?,?)',id,s)),auditStmt(env,user,'plan.save',id,{name,price_cents:price,service_ids:serviceIds}));if(old)q.push(guardCleanup(env,g));await env.DB.batch(q);return okay({plan:await first(env,'SELECT * FROM plans WHERE id=?',id)});
}
async function saveSchedule(request,env,user,b){
  const barberId=textValue(b.barber_id,1,100);if(!await first(env,'SELECT id FROM barbers WHERE id=?',barberId))fail(404,'Barbeiro não encontrado.');
  if(!Array.isArray(b.intervals)||b.intervals.length>28)fail(400,'Informe até 28 intervalos.');const intervals=b.intervals.map(w=>({weekday:integer(w.weekday,0,6),start_minute:integer(w.start_minute,0,1435),end_minute:integer(w.end_minute,5,1440)}));
  for(let i=0;i<intervals.length;i++){const x=intervals[i];if(x.start_minute>=x.end_minute||x.start_minute%5||x.end_minute%5)fail(400,'Intervalo de expediente inválido.');if(intervals.some((y,j)=>j<i&&x.weekday===y.weekday&&intersects(x.start_minute,x.end_minute,y.start_minute,y.end_minute)))fail(400,'Os intervalos de expediente não podem se sobrepor.');}
  const q=[stmt(env,'DELETE FROM weekly_hours WHERE barber_id=?',barberId),...intervals.map(w=>stmt(env,'INSERT INTO weekly_hours(id,barber_id,weekday,start_minute,end_minute) VALUES(?,?,?,?,?)',uid(),barberId,w.weekday,w.start_minute,w.end_minute)),auditStmt(env,user,'schedule.weekly',barberId,{intervals})];
  if(b.special_day){dateValue(b.special_day);if(!Array.isArray(b.special_intervals)||b.special_intervals.length>4)fail(400,'Informe os intervalos da abertura excepcional.');q.push(stmt(env,'DELETE FROM special_hours WHERE barber_id=? AND day=?',barberId,b.special_day));for(const w of b.special_intervals){const start=integer(w.start_minute,0,1435),end=integer(w.end_minute,start+5,1440);q.push(stmt(env,'INSERT INTO special_hours(id,barber_id,day,start_minute,end_minute) VALUES(?,?,?,?,?)',uid(),barberId,b.special_day,start,end));}}
  await env.DB.batch(q);const future=await rows(env,"SELECT id,local_day,start_minute,end_minute FROM appointments WHERE barber_id=? AND starts_at>? AND status IN('booked','waiting','in_service')",barberId,nowSeconds());
  const exceptions=[];for(const a of future){const ws=await getSchedule(env,barberId,a.local_day);if(!ws.some(w=>a.start_minute>=w.start_minute&&a.end_minute<=w.end_minute))exceptions.push(a);}
  return okay({ok:true,existing_bookings_outside_new_hours:exceptions,message:exceptions.length?'Expediente salvo. Há agendamentos fora da nova jornada; remarque-os manualmente.':'Expediente salvo.'});
}
async function saveSettings(request,env,user,b){
  const current=await configuration(env),value={...current};delete value.version;
  const numberKeys={minimum_notice_minutes:[0,1440],horizon_days:[1,90],cancellation_minutes:[0,10080],max_future_bookings:[1,10],slot_minutes:[5,30],inactive_days:[1,365]};
  for(const [k,[min,max]] of Object.entries(numberKeys))if(k in b)value[k]=integer(b[k],min,max);
  for(const k of ['business_name','address','instagram','privacy_contact'])if(k in b)value[k]=textValue(b[k],2,k==='privacy_contact'?1000:200);
  if('phone' in b)value.phone=phoneValue(b.phone);
  for(const k of ['payment_methods','expense_categories'])if(k in b){if(!Array.isArray(b[k])||b[k].length<1||b[k].length>15)fail(400,'Informe de 1 a 15 opções.');value[k]=[...new Set(b[k].map(s=>textValue(s,2,60)))];}
  if(b.notification_types){for(const k of Object.keys(DEFAULT_SETTINGS.notification_types))if(k in b.notification_types)value.notification_types[k]=b.notification_types[k]===true;}
  if(b.whatsapp_templates){value.whatsapp_templates={};for(const [k,v] of Object.entries(b.whatsapp_templates)){if(!(k in DEFAULT_SETTINGS.notification_types)||!/^[a-z0-9_]{1,150}$/.test(v))fail(400,'Nome de modelo WhatsApp inválido.');value.whatsapp_templates[k]=v;}}
  if('subscription_commission_mode' in b&&b.subscription_commission_mode!==null)fail(400,'A regra comercial de comissão de assinantes ainda precisa ser definida.');
  const g=uid();await env.DB.batch([guard(env,g,'SELECT EXISTS(SELECT 1 FROM settings WHERE id=1 AND version=?)',integer(b.version,1)),stmt(env,'UPDATE settings SET value=?,version=version+1 WHERE id=1',JSON.stringify(value)),auditStmt(env,user,'settings.update','1',{keys:Object.keys(b).filter(k=>k!=='version')}),guardCleanup(env,g)]);return okay({settings:{...value,version:current.version+1}});
}
async function financialReport(env,url){
  const p=parsePeriod(url);const receipts=await rows(env,'SELECT r.*,a.service_name,a.barber_name,u.name customer_name FROM receipts r JOIN appointments a ON a.id=r.appointment_id JOIN users u ON u.id=a.customer_id WHERE r.received_at>=? AND r.received_at<? ORDER BY r.received_at DESC',p.start,p.end);
  const expenses=await rows(env,'SELECT * FROM expenses WHERE occurred_at>=? AND occurred_at<? ORDER BY occurred_at DESC',p.start,p.end);
  const refunds=await rows(env,'SELECT r.*,rc.appointment_id FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE r.created_at>=? AND r.created_at<? ORDER BY r.created_at DESC',p.start,p.end);
  const commissions=await rows(env,'SELECT c.*,a.service_name,a.barber_name,a.starts_at,u.name customer_name,COALESCE((SELECT SUM(pa.amount_cents) FROM payout_allocation_balance pa WHERE pa.commission_id=c.id),0) paid_cents,COALESCE((SELECT SUM(r.barber_adjustment_cents) FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.appointment_id=c.appointment_id),0) refund_adjustment_cents FROM commissions c JOIN appointments a ON a.id=c.appointment_id JOIN users u ON u.id=a.customer_id WHERE c.created_at>=? AND c.created_at<? ORDER BY c.created_at DESC',p.start,p.end);
  const payouts=await rows(env,'SELECT p.*,b.name barber_name,COALESCE((SELECT SUM(amount_cents) FROM payout_returns pr WHERE pr.payout_id=p.id),0) returned_cents FROM payouts p JOIN barbers b ON b.id=p.barber_id WHERE p.paid_at>=? AND p.paid_at<? ORDER BY p.paid_at DESC',p.start,p.end);
  const pending=await rows(env,"SELECT a.*,u.name customer_name,COALESCE((SELECT SUM(amount_cents) FROM receipts r WHERE r.appointment_id=a.id),0) received_cents FROM appointments a JOIN users u ON u.id=a.customer_id WHERE a.status='completed' AND a.subscription_id IS NULL AND a.charged_cents>COALESCE((SELECT SUM(amount_cents) FROM receipts r WHERE r.appointment_id=a.id),0) ORDER BY a.completed_at DESC LIMIT 500");
  const subPayments=await rows(env,"SELECT p.*,s.plan_name,u.name customer_name FROM subscription_payments p JOIN subscriptions s ON s.id=p.subscription_id JOIN users u ON u.id=s.user_id WHERE p.paid_at>=? AND p.paid_at<? ORDER BY p.paid_at DESC",p.start,p.end);
  const sum=(list,k)=>list.reduce((n,r)=>n+r[k],0),received=sum(receipts,'amount_cents'),refunded=sum(refunds,'amount_cents'),spent=expenses.reduce((n,r)=>n+(r.reversal_of?-r.amount_cents:r.amount_cents),0),subRevenue=sum(subPayments.filter(r=>r.status==='confirmed'&&r.settled),'amount_cents'),earned=sum(commissions,'barber_cents')-sum(refunds,'barber_adjustment_cents');
  return okay({period:p,receipts,refunds,expenses,commissions:commissions.map(c=>({...c,pending_cents:c.barber_cents-c.paid_cents-c.refund_adjustment_cents})),payouts,pending_receipts:pending,subscription_payments:subPayments,summary:{single_received_cents:received,refunds_cents:refunded,single_net_received_cents:received-refunded,subscription_received_cents:subRevenue,subscription_confirmed_cents:sum(subPayments.filter(r=>r.status==='confirmed'),'amount_cents'),expenses_cents:spent,commission_earned_cents:earned,payouts_cents:sum(payouts,'amount_cents'),estimated_operating_result_cents:received-refunded+subRevenue-spent-earned,result_note:'Estimativa antes de taxas de cartão, gateway, impostos e demais custos não registrados. Comissões são deduzidas por competência; repasses não são descontados duas vezes.'}});
}
async function addReceipt(request,env,user,b){
  const key=requestKey(request,b),old=await first(env,'SELECT * FROM receipts WHERE request_key=?',key);if(old)return okay({receipt:old,idempotent:true});const a=await authorizedAppointment(env,user,textValue(b.appointment_id,1,100));
  if(!(await configuration(env)).payment_methods.includes(b.method))fail(400,'Forma de pagamento inválida.');const id=uid(),amount=integer(b.amount_cents,1,a.charged_cents||0);
  await env.DB.batch([stmt(env,'INSERT INTO receipts(id,appointment_id,amount_cents,method,received_at,request_key,created_by) VALUES(?,?,?,?,?,?,?)',id,a.id,amount,b.method,nowSeconds(),key,user.id),auditStmt(env,user,'receipt.create',id,{appointment_id:a.id,amount_cents:amount,method:b.method})]);return json({id},201);
}
async function addPayout(request,env,user,b){
  const key=requestKey(request,b),old=await first(env,'SELECT * FROM payouts WHERE request_key=?',key);if(old)return okay({payout:old,idempotent:true});
  const barberId=textValue(b.barber_id,1,100);if(!Array.isArray(b.allocations)||!b.allocations.length||b.allocations.length>100)fail(400,'Selecione de 1 a 100 comissões.');
  if(!(await configuration(env)).payment_methods.includes(b.method))fail(400,'Forma de pagamento inválida.');const ids=new Set(),allocations=b.allocations.map(a=>{if(ids.has(a.commission_id))fail(400,'Comissão repetida.');ids.add(a.commission_id);return {commission_id:textValue(a.commission_id,1,100),amount_cents:integer(a.amount_cents,1,10000000)};});
  const amount=allocations.reduce((n,a)=>n+a.amount_cents,0),id=uid(),notes=textValue(b.notes||'',0,500);
  if(b.receipt_key&&!await first(env,"SELECT id FROM uploads WHERE object_key=? AND purpose='receipt'",b.receipt_key))fail(400,'Comprovante inválido.');
  await env.DB.batch([stmt(env,'INSERT INTO payouts(id,barber_id,amount_cents,method,paid_at,receipt_key,notes,request_key,created_by) VALUES(?,?,?,?,?,?,?,?,?)',id,barberId,amount,b.method,nowSeconds(),b.receipt_key||null,notes,key,user.id),...allocations.map(a=>stmt(env,'INSERT INTO payout_allocations(payout_id,commission_id,amount_cents) VALUES(?,?,?)',id,a.commission_id,a.amount_cents)),auditStmt(env,user,'payout.create',id,{barber_id:barberId,amount_cents:amount,allocations})]);return json({id,amount_cents:amount},201);
}
async function addExpense(request,env,user,b){
  const key=requestKey(request,b),old=await first(env,'SELECT id FROM expenses WHERE request_key=?',key);if(old)return okay({id:old.id,idempotent:true});const cfg=await configuration(env);if(!cfg.payment_methods.includes(b.method)||!cfg.expense_categories.includes(b.category))fail(400,'Categoria ou forma de pagamento inválida.');const id=uid(),amount=integer(b.amount_cents,1,100000000),description=textValue(b.description,2,300);let original=null;if(b.reversal_of){original=await first(env,'SELECT * FROM expenses WHERE id=?',b.reversal_of);if(!original||original.reversal_of||original.amount_cents!==amount)fail(400,'Reversão de despesa inválida.');}
  await env.DB.batch([stmt(env,'INSERT INTO expenses(id,amount_cents,category,description,method,occurred_at,created_by,reversal_of,request_key) VALUES(?,?,?,?,?,?,?,?,?)',id,amount,b.category,description,b.method,nowSeconds(),user.id,original?.id||null,key),auditStmt(env,user,original?'expense.reversal':'expense.create',id,{amount_cents:amount,original_id:original?.id||null})]);return json({id},201);
}
async function addPayoutReturn(request,env,user,b){
  const key=requestKey(request,b);const old=await first(env,'SELECT id FROM payout_returns WHERE request_key=?',key);if(old)return okay({id:old.id,idempotent:true});
  const payout=await first(env,'SELECT * FROM payouts WHERE id=?',textValue(b.payout_id,1,100));if(!payout)fail(404,'Repasse não encontrado.');
  const amount=integer(b.amount_cents,1,payout.amount_cents),reason=textValue(b.reason,5,500);if(!(await configuration(env)).payment_methods.includes(b.method))fail(400,'Forma de devolução inválida.');
  const allocations=await rows(env,'SELECT * FROM payout_allocation_balance WHERE payout_id=? ORDER BY commission_id',payout.id);let remaining=amount;const changes=[];for(const a of allocations){const returned=Math.min(remaining,a.amount_cents);if(returned>0)changes.push(stmt(env,'INSERT INTO payout_returns(id,payout_id,commission_id,amount_cents,method,returned_at,reason,request_key,created_by) VALUES(?,?,?,?,?,?,?,?,?)',uid(),payout.id,a.commission_id,returned,b.method,nowSeconds(),reason,key,user.id));remaining-=returned;}
  if(remaining>0)fail(409,'A devolução ultrapassa o valor ainda não devolvido deste repasse.');
  changes.push(auditStmt(env,user,'payout.return',payout.id,{amount_cents:amount,reason,method:b.method}));await env.DB.batch(changes);return json({ok:true,amount_cents:amount},201);
}
async function addRefund(request,env,user,b){
  const key=requestKey(request,b),old=await first(env,'SELECT id FROM refunds WHERE request_key=?',key);if(old)return okay({id:old.id,idempotent:true});const receipt=await first(env,'SELECT r.*,a.charged_cents,c.barber_cents,c.id commission_id FROM receipts r JOIN appointments a ON a.id=r.appointment_id JOIN commissions c ON c.appointment_id=a.id WHERE r.id=?',textValue(b.receipt_id,1,100));if(!receipt)fail(404,'Recebimento não encontrado.');
  const amount=integer(b.amount_cents,1,receipt.amount_cents),reason=textValue(b.reason,5,500),prior=await first(env,'SELECT COALESCE(SUM(r.amount_cents),0) refunded,COALESCE(SUM(r.barber_adjustment_cents),0) adjustment FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.appointment_id=?',receipt.appointment_id);
  const adjustment=Math.round(receipt.barber_cents*(prior.refunded+amount)/receipt.charged_cents)-prior.adjustment;const id=uid();
  await env.DB.batch([stmt(env,'INSERT INTO refunds(id,receipt_id,amount_cents,barber_adjustment_cents,reason,created_at,created_by,request_key) VALUES(?,?,?,?,?,?,?,?)',id,receipt.id,amount,adjustment,reason,nowSeconds(),user.id,key),auditStmt(env,user,'receipt.refund',id,{receipt_id:receipt.id,amount_cents:amount,barber_adjustment_cents:adjustment,reason})]);return json({id},201);
}
async function manageCash(request,env,user,b){
  const day=dateValue(b.day||localParts().day);if(day!==localParts().day)fail(400,'Abra e feche apenas o caixa de hoje.');const existing=await first(env,'SELECT * FROM cash_sessions WHERE day=?',day);
  if(b.action==='open'){if(existing)fail(409,'Já existe um caixa para esta data.');const id=uid();await env.DB.batch([stmt(env,'INSERT INTO cash_sessions(id,day,opening_cents,opened_at,created_by) VALUES(?,?,?,?,?)',id,day,integer(b.opening_cents,0,100000000),nowSeconds(),user.id),auditStmt(env,user,'cash.open',id)]);return okay({id});}
  if(b.action!=='close'||!existing||existing.closed_at)fail(409,'Não existe caixa aberto para fechar.');
  const start=zonedEpoch(day,0),end=zonedEpoch(day,1440),cashIn=await first(env,"SELECT COALESCE(SUM(amount_cents),0) amount FROM receipts WHERE method='Dinheiro' AND received_at>=? AND received_at<?",start,end),cashOut=await first(env,"SELECT COALESCE(SUM(CASE WHEN reversal_of IS NULL THEN amount_cents ELSE -amount_cents END),0) amount FROM expenses WHERE method='Dinheiro' AND occurred_at>=? AND occurred_at<?",start,end),cashPayout=await first(env,"SELECT COALESCE(SUM(amount_cents),0) amount FROM payouts WHERE method='Dinheiro' AND paid_at>=? AND paid_at<?",start,end),cashRefund=await first(env,"SELECT COALESCE(SUM(r.amount_cents),0) amount FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.method='Dinheiro' AND r.created_at>=? AND r.created_at<?",start,end);
  const expected=existing.opening_cents+cashIn.amount-cashOut.amount-cashPayout.amount-cashRefund.amount,g=uid();
  // Snapshot and closure execute under the same write transaction. SQL recomputes the balance.
  await env.DB.batch([guard(env,g,'SELECT EXISTS(SELECT 1 FROM cash_sessions WHERE id=? AND closed_at IS NULL)',existing.id),stmt(env,"UPDATE cash_sessions SET counted_cents=?,expected_cents=opening_cents+COALESCE((SELECT SUM(amount_cents) FROM receipts WHERE method='Dinheiro' AND received_at>=? AND received_at<?),0)-COALESCE((SELECT SUM(CASE WHEN reversal_of IS NULL THEN amount_cents ELSE -amount_cents END) FROM expenses WHERE method='Dinheiro' AND occurred_at>=? AND occurred_at<?),0)-COALESCE((SELECT SUM(amount_cents) FROM payouts WHERE method='Dinheiro' AND paid_at>=? AND paid_at<?),0)+COALESCE((SELECT SUM(amount_cents) FROM payout_returns WHERE method='Dinheiro' AND returned_at>=? AND returned_at<?),0)-COALESCE((SELECT SUM(r.amount_cents) FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.method='Dinheiro' AND r.created_at>=? AND r.created_at<?),0),notes=?,closed_at=? WHERE id=?",integer(b.counted_cents,0,100000000),start,end,start,end,start,end,start,end,start,end,textValue(b.notes||'',0,500),nowSeconds(),existing.id),auditStmt(env,user,'cash.close',existing.id,{counted_cents:b.counted_cents}),guardCleanup(env,g)]);return okay({session:await first(env,'SELECT * FROM cash_sessions WHERE id=?',existing.id)});
}
async function reports(env,url){
  const p=parsePeriod(url),barber=url.searchParams.get('barber_id')||'';
  const byBarber=await rows(env,"SELECT a.barber_id,a.barber_name,COUNT(*) bookings,SUM(a.status='completed') completed,SUM(a.status='cancelled') cancelled,SUM(a.status='no_show') no_shows,COUNT(DISTINCT CASE WHEN a.status='completed' THEN a.customer_id END) unique_clients,COALESCE(SUM(CASE WHEN a.status='completed' AND a.subscription_id IS NULL THEN a.charged_cents ELSE 0 END),0) charged_single_cents,SUM(a.status='completed' AND a.subscription_id IS NOT NULL) subscriber_visits,COALESCE(SUM(CASE WHEN a.status='completed' THEN a.duration_minutes ELSE 0 END),0) served_minutes,COUNT(DISTINCT CASE WHEN a.status='completed' AND EXISTS(SELECT 1 FROM appointments prev WHERE prev.customer_id=a.customer_id AND prev.status='completed' AND prev.completed_at<a.completed_at) THEN a.customer_id END) recurring_clients FROM appointments a WHERE a.starts_at>=? AND a.starts_at<? AND (?='' OR a.barber_id=?) GROUP BY a.barber_id,a.barber_name",p.start,p.end,barber,barber);
  const byService=await rows(env,"SELECT service_id,service_name,COUNT(*) visits,SUM(subscription_id IS NOT NULL) subscriber_visits,COALESCE(SUM(charged_cents),0) charged_cents FROM appointments WHERE status='completed' AND starts_at>=? AND starts_at<? AND (?='' OR barber_id=?) GROUP BY service_id,service_name ORDER BY visits DESC",p.start,p.end,barber,barber);
  const byDay=await rows(env,"SELECT local_day,COUNT(*) bookings,SUM(status='completed') completed,COALESCE(SUM(charged_cents),0) charged_cents FROM appointments WHERE starts_at>=? AND starts_at<? AND (?='' OR barber_id=?) GROUP BY local_day ORDER BY local_day",p.start,p.end,barber,barber);
  const allBarbers=await rows(env,"SELECT id,name FROM barbers WHERE (?='' OR id=?)",barber,barber),occupancy=[];
  const weekly=await rows(env,'SELECT * FROM weekly_hours'),special=await rows(env,'SELECT * FROM special_hours WHERE day>=? AND day<?',p.from,p.to),blocks=await rows(env,'SELECT * FROM blocks WHERE starts_at<? AND ends_at>?',p.end,p.start);
  const booked=await rows(env,"SELECT barber_id,COALESCE(SUM(duration_minutes),0) mins FROM appointments WHERE starts_at>=? AND starts_at<? AND status NOT IN('cancelled','no_show') GROUP BY barber_id",p.start,p.end);
  const earned=await rows(env,'SELECT c.barber_id,SUM(c.barber_cents) earned,COALESCE(SUM((SELECT SUM(pa.amount_cents) FROM payout_allocation_balance pa WHERE pa.commission_id=c.id)),0) paid FROM commissions c WHERE c.created_at>=? AND c.created_at<? GROUP BY c.barber_id',p.start,p.end);
  for(const b of allBarbers){let open=0;for(let day=p.from;day<p.to;day=addDays(day,1)){const exceptions=special.filter(w=>w.barber_id===b.id&&w.day===day);const intervals=exceptions.length?exceptions:weekly.filter(w=>w.barber_id===b.id&&w.weekday===weekday(day));const blocked=blocks.filter(bl=>(!bl.barber_id||bl.barber_id===b.id)&&bl.starts_at<zonedEpoch(day,1440)&&bl.ends_at>zonedEpoch(day,0));for(const w of intervals)for(let m=w.start_minute;m<w.end_minute;m+=5){const start=zonedEpoch(day,m);if(!blocked.some(bl=>intersects(start,start+300,bl.starts_at,bl.ends_at)))open+=5;}}
    const busy=booked.find(x=>x.barber_id===b.id),c=earned.find(x=>x.barber_id===b.id);occupancy.push({barber_id:b.id,available_minutes:open,booked_minutes:busy?.mins||0,occupancy_percent:open?Math.round((busy?.mins||0)/open*100):0,commission_earned_cents:c?.earned||0,commission_paid_cents:c?.paid||0});}
  return okay({period:p,by_barber:byBarber,by_service:byService,by_day:byDay,occupancy});
}
async function exportReport(env,url){
  const p=parsePeriod(url);const data=await rows(env,'SELECT a.local_day,a.service_name,a.barber_name,u.name customer_name,a.status,a.price_cents,a.charged_cents,COALESCE((SELECT SUM(amount_cents) FROM receipts r WHERE r.appointment_id=a.id),0) received_cents,CASE WHEN a.subscription_id IS NOT NULL THEN \'Assinatura\' ELSE \'Avulso\' END type FROM appointments a JOIN users u ON u.id=a.customer_id WHERE a.starts_at>=? AND a.starts_at<? ORDER BY a.starts_at',p.start,p.end);
  const headers=['Data','Serviço','Barbeiro','Cliente','Status','Tabela (centavos)','Cobrado (centavos)','Recebido (centavos)','Tipo'];const escape=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replaceAll('"','""')+'"';const csv='\uFEFF'+[headers,...data.map(r=>[r.local_day,r.service_name,r.barber_name,r.customer_name,STATUS[r.status],r.price_cents,r.charged_cents,r.received_cents,r.type])].map(r=>r.map(escape).join(';')).join('\r\n');return new Response(csv,{headers:{'content-type':'text/csv; charset=utf-8','content-disposition':'attachment; filename="dom-rodrigues-'+p.from+'.csv"','cache-control':'no-store'}});
}
async function createSubscription(request,env,user,b){
  if(user.role!=='customer')fail(403,'Entre como cliente para contratar.');const plan=await first(env,'SELECT * FROM plans WHERE id=? AND active=1 AND for_sale=1',b.plan_id);if(!plan)fail(409,'Este plano ainda não foi liberado por Rodrigues.');
  const key=requestKey(request,b),prior=await first(env,'SELECT * FROM subscriptions WHERE request_key=? AND user_id=?',key,user.id);if(prior)return okay({subscription:prior,idempotent:true});const current=await first(env,"SELECT id FROM subscriptions WHERE user_id=? AND status IN('pending','active','past_due')",user.id);if(current)fail(409,'Você já tem uma assinatura ativa ou uma contratação pendente. Consulte Minha conta.');
  if(env.DEMO_MODE!=='true'&&!integrationStatus(env).asaas.configured)fail(503,'O checkout sandbox está pendente de configuração. Nenhuma cobrança foi criada.','asaas_unconfigured');
  const id=uid(),mode=env.DEMO_MODE==='true'?'demo':env.ASAAS_MODE==='production'?'production':'sandbox';const services=await rows(env,'SELECT service_id FROM plan_services WHERE plan_id=?',plan.id);if(!services.length)fail(409,'Rodrigues ainda precisa definir os serviços do plano.');
  await env.DB.batch([stmt(env,"INSERT INTO subscriptions(id,user_id,plan_id,plan_name,price_cents,status,provider_mode,request_key,created_at) VALUES(?,?,?,?,?,'pending',?,?,?)",id,user.id,plan.id,plan.name,plan.price_cents,mode,key,nowSeconds()),...services.map(s=>stmt(env,'INSERT INTO subscription_services(subscription_id,service_id) VALUES(?,?)',id,s.service_id)),auditStmt(env,user,'subscription.request',id,{mode,plan_id:plan.id})]);const sub=await first(env,'SELECT * FROM subscriptions WHERE id=?',id);
  if(mode==='demo')return json({subscription:sub,requires_demo_confirmation:true,message:'Contrato de demonstração criado. Rodrigues pode confirmar um pagamento de teste no painel. Nenhum dinheiro foi movimentado.'},201);
  try{return json({subscription:sub,...await createHostedCheckout(env,request,sub)},201);}catch(e){await auditStmt(env,user,'subscription.checkout_failed',id,{message:'Consultar provedor e conciliar antes de recriar.'}).run();throw e;}
}
async function cancelSubscription(request,env,user,id){
  const sub=await first(env,'SELECT * FROM subscriptions WHERE id=? AND user_id=?',id,user.id);if(!sub)fail(404,'Assinatura não encontrada.');if(sub.cancel_at_end)return okay({subscription:sub,idempotent:true});
  if(sub.provider_mode!=='demo'){
    if(sub.provider_id)await asaasRequest(env,'/subscriptions/'+encodeURIComponent(sub.provider_id),'DELETE');
    else if(sub.checkout_id){await asaasRequest(env,'/checkouts/'+encodeURIComponent(sub.checkout_id)+'/cancel','POST');}
  }
  await env.DB.batch([stmt(env,"UPDATE subscriptions SET status='cancelled',cancel_at_end=1 WHERE id=?",id),auditStmt(env,user,'subscription.cancel',id,{valid_until:sub.valid_until})]);return okay({message:'Renovação cancelada. Os benefícios continuam até o fim do período já pago.',subscription:await first(env,'SELECT * FROM subscriptions WHERE id=?',id)});
}
async function demoSubscriptionPayment(request,env,user,b){
  if(env.DEMO_MODE!=='true')fail(403,'A confirmação demonstrativa está desativada.');const sub=await first(env,"SELECT * FROM subscriptions WHERE id=? AND provider_mode='demo'",b.subscription_id);if(!sub)fail(404,'Contrato de demonstração não encontrado.');if(sub.cancel_at_end)fail(409,'Esta assinatura está cancelada. Recontrate para testar outro ciclo.');const key=requestKey(request,b),old=await first(env,'SELECT id FROM subscription_payments WHERE provider_payment_id=?','demo-'+key);if(old)return okay({idempotent:true});
  const base=Math.max(nowSeconds(),sub.valid_until);const d=new Date(base*1000);d.setUTCMonth(d.getUTCMonth()+1);const end=Math.floor(+d/1000);
  await env.DB.batch([stmt(env,"INSERT INTO subscription_payments(id,subscription_id,provider_payment_id,amount_cents,status,paid_at,period_end,provider_mode,settled) VALUES(?,?,?,?,'confirmed',?,?,'demo',1)",uid(),sub.id,'demo-'+key,sub.price_cents,nowSeconds(),end),stmt(env,"UPDATE subscriptions SET status='active',valid_until=? WHERE id=?",end,sub.id),auditStmt(env,user,'demo.subscription_payment',sub.id,{amount_cents:sub.price_cents,valid_until:end})]);return okay({message:'Pagamento de teste confirmado. Benefícios demonstrativos liberados.'});
}
async function uploadFile(request,env,user,url){
  if(!env.BUCKET)fail(503,'Armazenamento de arquivos não configurado.');const purpose=url.searchParams.get('purpose');if(!['barber','receipt'].includes(purpose))fail(400,'Finalidade de arquivo inválida.');const mime=(request.headers.get('content-type')||'').split(';')[0];const max=purpose==='barber'?2*1024*1024:5*1024*1024;
  const size=Number(request.headers.get('content-length'));if(size>max)fail(413,'Arquivo muito grande.');if(!['image/jpeg','image/png','image/webp',...(purpose==='receipt'?['application/pdf']:[])].includes(mime))fail(415,'Envie JPEG, PNG ou WebP; comprovantes também aceitam PDF.');
  const reader=request.body?.getReader();if(!reader)fail(400,'Arquivo vazio.');let total=0,chunks=[];while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>max){await reader.cancel();fail(413,'Arquivo muito grande.');}chunks.push(value);}const bytes=new Uint8Array(total);let n=0;for(const c of chunks){bytes.set(c,n);n+=c.length;}
  const head=Array.from(bytes.slice(0,12)).map(x=>x.toString(16).padStart(2,'0')).join('');const valid=mime==='image/jpeg'?head.startsWith('ffd8ff'):mime==='image/png'?head.startsWith('89504e470d0a1a0a'):mime==='image/webp'?new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP':new TextDecoder().decode(bytes.slice(0,5))==='%PDF-';if(!valid||total<20)fail(415,'O conteúdo do arquivo não corresponde ao tipo informado.');
  const key=purpose+'/'+uid()+({ 'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp','application/pdf':'.pdf'}[mime]);await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:mime}});const id=uid();try{await env.DB.batch([stmt(env,'INSERT INTO uploads(id,object_key,mime,size_bytes,purpose,created_by,created_at) VALUES(?,?,?,?,?,?,?)',id,key,mime,total,purpose,user.id,nowSeconds()),auditStmt(env,user,'upload.create',id,{purpose,size_bytes:total})]);}catch(e){await env.BUCKET.delete(key);throw e;}return json({object_key:key,url:'/media/'+encodeURIComponent(key)},201);
}
async function serveMedia(request,env,url){
  if(!env.BUCKET||!env.DB)fail(404,'Arquivo não encontrado.');let key;try{key=decodeURIComponent(url.pathname.slice(7));}catch{fail(400,'Nome inválido.');}const record=await first(env,'SELECT * FROM uploads WHERE object_key=?',key);if(!record)fail(404,'Arquivo não encontrado.');const publicPhoto=record.purpose==='barber'&&await first(env,'SELECT id FROM barbers WHERE photo_key=? AND active=1',key);if(!publicPhoto)await requireUser(env,request,true);const obj=await env.BUCKET.get(key);if(!obj)fail(404,'Arquivo não encontrado.');return new Response(obj.body,{headers:{'content-type':record.mime,'cache-control':publicPhoto?'public,max-age=3600':'no-store',...(record.purpose==='receipt'?{'content-disposition':'attachment; filename="comprovante'+(record.mime==='application/pdf'?'.pdf':'.img')+'"'}:{})}});
}

async function scheduledWork(env){
  const now=nowSeconds();const appointments=await rows(env,"SELECT * FROM appointments WHERE status='booked' AND starts_at>? AND starts_at<=?",now+23*3600,now+24*3600+600);
  for(const a of appointments)await enqueueNotification(env,a.customer_id,'reminder_24h',a.id,{parameters:[a.service_name,a.local_day,localParts(a.starts_at).time,a.barber_name]},'reminder_24h:'+a.id);
  const subs=await rows(env,"SELECT * FROM subscriptions WHERE status IN('active','past_due') AND valid_until>? AND valid_until<=?",now,now+86400);
  for(const sub of subs)await enqueueNotification(env,sub.user_id,'subscription_due',sub.id,{parameters:[sub.plan_name,localParts(sub.valid_until).day]},'subscription_due:'+sub.id+':'+sub.valid_until);
  await env.DB.batch([stmt(env,'DELETE FROM sessions WHERE expires_at<?',now),stmt(env,'DELETE FROM challenges WHERE expires_at<?',now-86400),stmt(env,'DELETE FROM rate_limits WHERE expires_at<?',now-86400)]);
  return processNotifications(env);
}

function secureHeaders(response){const out=new Response(response.body,response);out.headers.set('x-content-type-options','nosniff');out.headers.set('referrer-policy','same-origin');out.headers.set('permissions-policy','camera=(), microphone=(), geolocation=()');out.headers.set('strict-transport-security','max-age=31536000; includeSubDomains');out.headers.set('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'; form-action 'self'; upgrade-insecure-requests");return out;}
const sqlErrors={RETURN_EXCEEDS_PAYOUT:'A devolução excede o valor disponível deste repasse.',IMMUTABLE_FINANCIAL_RECORD:'O histórico financeiro não pode ser apagado. Registre um ajuste auditável.',SLOT_CONFLICT:'Este horário acabou de ser reservado. Escolha outro.',BLOCKED:'O horário foi bloqueado por Rodrigues.',OUTSIDE_HOURS:'O horário está fora do expediente configurado.',FUTURE_LIMIT:'Você já tem um agendamento futuro ativo.',CUSTOMER_UNVERIFIED:'Confirme o telefone antes de agendar.',CATALOG_CHANGED:'O serviço ou profissional mudou. Atualize a página.',SUBSCRIPTION_INVALID:'O benefício da assinatura não está válido para esse horário.',EXISTING_BOOKINGS:'Há agendamentos neste período. Remarque ou cancele antes de bloquear.',COMMISSION_ALREADY_PAID:'Esta comissão já foi paga total ou parcialmente. Atualize os saldos.',PAYOUT_OVERALLOCATED:'A distribuição excede o valor do repasse.',OVERPAYMENT:'O valor recebido excede o valor do atendimento.',NOT_PAYABLE:'O atendimento ainda não pode receber pagamento.',CASH_CLOSED:'O caixa desta data já está fechado.',SETTLED_COMMISSION_REQUIRES_REVIEW:'A comissão deste atendimento já foi repassada. Registre a devolução do barbeiro antes do ajuste.',REFUND_EXCEEDS_RECEIPT:'O estorno excede o recebimento disponível.'};
export default {
  async fetch(request,env,ctx){try{
    const url=new URL(request.url);if(url.pathname.startsWith('/api/'))return secureHeaders(await apiRoute(request,env,ctx));
    if(url.pathname.startsWith('/media/'))return secureHeaders(await serveMedia(request,env,url));
    if(!['GET','HEAD'].includes(request.method))return secureHeaders(json({error:'Método não permitido.'},405));
    const alias=['/admin','/agenda','/conta','/agendar','/clube','/profissionais','/servicos'].includes(url.pathname)?'/index.html':url.pathname==='/'?'/index.html':url.pathname;
    let response;if(env.ASSETS){response=await env.ASSETS.fetch(new Request(new URL(alias,url),request));}else{const asset=ASSET_MAP[alias];response=asset?new Response(Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0)),{headers:{'content-type':asset.type,'cache-control':alias.startsWith('/assets/')?'public,max-age=86400':'no-cache'}}):new Response('Página não encontrada',{status:404});}
    if(request.method==='HEAD')response=new Response(null,response);return secureHeaders(response);
  }catch(e){if(e instanceof HttpError)return secureHeaders(json({error:e.message,code:e.code},e.status));const message=String(e?.message||e);for(const [code,human] of Object.entries(sqlErrors))if(message.includes(code))return secureHeaders(json({error:human,code},409));if(message.includes('guards.ok')||message.includes('CHECK constraint failed: ok=1'))return secureHeaders(json({error:'Os dados foram alterados em outra operação. Atualize a página.',code:'version_conflict'},409));if(message.includes('UNIQUE constraint failed'))return secureHeaders(json({error:'Esta operação já foi registrada. Atualize a página.',code:'duplicate'},409));console.error('DomRodrigues request failed',new URL(request.url).pathname,e?.name||'Error');return secureHeaders(json({error:'Não foi possível concluir a operação. Tente novamente ou consulte Rodrigues.',code:'internal_error'},500));}},
  async scheduled(event,env,ctx){ctx.waitUntil(scheduledWork(env));}
};
