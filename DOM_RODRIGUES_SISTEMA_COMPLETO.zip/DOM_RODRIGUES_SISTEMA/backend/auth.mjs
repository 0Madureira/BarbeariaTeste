import { scrypt, timingSafeEqual } from 'node:crypto';
import { fail, nowSeconds, uid, phoneValue, textValue } from './domain.mjs';
const encoder = new TextEncoder();
export const hex=bytes=>Array.from(new Uint8Array(bytes),x=>x.toString(16).padStart(2,'0')).join('');
export const randomToken=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
export const digest=async value=>hex(await crypto.subtle.digest('SHA-256',encoder.encode(value)));
export function secretEqual(a,b){const x=encoder.encode(String(a||'')),y=encoder.encode(String(b||''));return x.length===y.length&&x.length>0&&timingSafeEqual(x,y);}
export function requirePepper(env){if(!env.AUTH_PEPPER||env.AUTH_PEPPER.length<32)fail(503,'A autenticação precisa de um segredo seguro configurado.','auth_unconfigured');return env.AUTH_PEPPER;}
let hashingQueue=Promise.resolve();
async function scryptKey(password,salt,pepper){
  // Serialize memory-hard work per isolate; avoid multiplying the 32MiB work area.
  const previous=hashingQueue;let unlock;hashingQueue=new Promise(r=>{unlock=r;});await previous;
  try{
    const key=await crypto.subtle.importKey('raw',encoder.encode(pepper),{name:'HMAC',hash:'SHA-256'},false,['sign']);
    const prehash=hex(await crypto.subtle.sign('HMAC',key,encoder.encode(password)));
    return await new Promise((resolve,reject)=>scrypt(prehash,salt,32,{N:32768,r:8,p:3,maxmem:64*1024*1024},(e,k)=>e?reject(e):resolve(hex(k))));
  }finally{unlock();}
}
export function passwordValue(p,admin=false){textValue(p,admin?16:10,128);if(typeof p!=='string'||p!==p.trim())fail(400,'A senha não deve começar ou terminar com espaços.');return p;}
export async function passwordHash(p,env){const salt=randomToken();return `scrypt$32768$8$3$${salt}$${await scryptKey(p,salt,requirePepper(env))}`;}
export async function passwordMatches(p,stored,env){if(!stored||typeof p!=='string'||p.length>128)return false;const [algo,N,r,parallel,salt,want]=stored.split('$');if(algo!=='scrypt'||N!=='32768'||r!=='8'||parallel!=='3'||!salt||!want)return false;return secretEqual(await scryptKey(p,salt,requirePepper(env)),want);}
export function stmt(env,sql,...values){return env.DB.prepare(sql).bind(...values.map(x=>x===undefined?null:x));}
export async function rows(env,sql,...values){return (await stmt(env,sql,...values).all()).results;}
export async function first(env,sql,...values){return stmt(env,sql,...values).first();}
export function auditStmt(env,user,action,entity,details={}){return stmt(env,'INSERT INTO audit_log(id,actor_id,action,entity_id,details,created_at) VALUES(?,?,?,?,?,?)',uid(),user?.id||null,action,entity,JSON.stringify(details),nowSeconds());}
export async function rateLimit(env,request,label,maximum=15,seconds=900,subject=''){
  const ip=subject?'subject-wide':request.headers.get('cf-connecting-ip')||request.headers.get('x-real-ip')||'unavailable';
  const key=await digest(`${label}:${subject}:${ip}:${requirePepper(env)}`),now=nowSeconds();
  const result=await stmt(env,'INSERT INTO rate_limits(id,hits,expires_at) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET hits=CASE WHEN expires_at<=? THEN 1 ELSE hits+1 END,expires_at=CASE WHEN expires_at<=? THEN excluded.expires_at ELSE expires_at END RETURNING hits',key,now+seconds,now,now).first();
  if(result.hits>maximum)fail(429,'Muitas tentativas. Aguarde alguns minutos e tente novamente.','rate_limited');
}
export function sessionCookie(token,maxAge=43200){return `__Host-dom_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;}
export async function createSession(env,user){const token=randomToken(),csrf=randomToken(),now=nowSeconds();await stmt(env,'INSERT INTO sessions(token_hash,user_id,csrf,expires_at,created_at) VALUES(?,?,?,?,?)',await digest(token),user.id,csrf,now+(user.role==='admin'?43200:604800),now).run();return {cookie:sessionCookie(token,user.role==='admin'?43200:604800),csrf,user:publicUser(user)};}
export function publicUser(u){return {id:u.id,name:u.name,phone:u.phone,role:u.role,verified:!!u.verified,consent_service:!!u.consent_service,consent_marketing:!!u.consent_marketing};}
export async function getSession(env,request){const token=(request.headers.get('cookie')||'').match(/(?:^|;\s*)__Host-dom_session=([a-f0-9]{64})(?:;|$)/)?.[1];if(!token)return null;return first(env,'SELECT u.*,s.csrf,s.token_hash FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1',await digest(token),nowSeconds());}
export function checkOrigin(request){const origin=request.headers.get('origin');if(origin!==new URL(request.url).origin)fail(403,'Origem da solicitação não permitida.','origin_rejected');}
export function checkCSRF(request,user){if(!user||!secretEqual(request.headers.get('x-csrf-token'),user.csrf))fail(403,'Sua sessão precisa ser atualizada. Recarregue a página.','csrf_rejected');}
export async function requireUser(env,request,admin=false){const u=await getSession(env,request);if(!u)fail(401,'Entre na sua conta para continuar.','login_required');if(admin&&u.role!=='admin')fail(403,'Acesso exclusivo do Rodrigues.','admin_required');if(!['GET','HEAD'].includes(request.method))checkCSRF(request,u);return u;}
export async function bodyJSON(request,max=65536){if(!request.headers.get('content-type')?.includes('application/json'))fail(415,'Envie dados no formato JSON.');if(Number(request.headers.get('content-length'))>max)fail(413,'Solicitação muito grande.');const reader=request.body?.getReader();if(!reader)return {};let total=0,chunks=[];while(true){const {value,done}=await reader.read();if(done)break;total+=value.byteLength;if(total>max){await reader.cancel();fail(413,'Solicitação muito grande.');}chunks.push(value);}const all=new Uint8Array(total);let at=0;for(const b of chunks){all.set(b,at);at+=b.length;}try{return JSON.parse(new TextDecoder().decode(all));}catch{fail(400,'JSON inválido.');}}
export function requestKey(request,b){const key=request.headers.get('idempotency-key')||b?.request_key;if(!key||!/^[a-zA-Z0-9_-]{8,120}$/.test(key))fail(400,'Informe uma chave de idempotência válida.');return key;}
