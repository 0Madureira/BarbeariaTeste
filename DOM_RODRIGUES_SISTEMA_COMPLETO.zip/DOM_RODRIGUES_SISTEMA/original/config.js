/* DOM RODRIGUES — edite este arquivo com um editor de texto.
 * Mantenha aspas, vírgulas e colchetes. Não coloque dados de clientes aqui.
 * Use null para preço/duração desconhecidos. Consulte LEIA-ME.html.
 */
window.DOM_CONFIG = {
  business: {
    name: "Dom Rodrigues Barbearia",
    slogan: "Seu visual é sua assinatura",
    whatsapp: "5521970594489", // país + DDD + número, somente dígitos
    phoneDisplay: "(21) 97059-4489",
    instagram: "domr.rodrigues2026", // sem @
    address: "Rua Luiz Sobral, 492, Califórnia, Nova Iguaçu/RJ",
    mapsUrl: "", // Opcional: link oficial do ponto no Google Maps, confirmado pelo proprietário.
    street: "Rua Luiz Sobral, 492",
    neighborhood: "Califórnia",
    city: "Nova Iguaçu",
    state: "RJ",
    logo: "assets/logo-referencia.webp",
    // Preencha depois da publicação. Sem barra no final. Ex.: https://seusite.pages.dev
    siteUrl: "",
    hours: [], // Ex.: [{days:"Segunda a sexta", time:"09h às 19h"}]. CONFIRME antes de preencher.
    // Opcional: foto original AUTORIZADA na primeira dobra.
    heroImage: "", // Ex.: assets/fotos/ambiente.webp
    heroImageAlt: "Ambiente da Dom Rodrigues Barbearia",
    heroImagePosition: "center"
  },
  texts: {
    heroEyebrow: "DOM RODRIGUES · BARBEARIA",
    heroLead: "Cortes e barbas com identidade. Encontre seu estilo na Califórnia, em Nova Iguaçu.",
    aboutTitle: "Um endereço.\nA sua identidade.",
    aboutBody: "A Dom Rodrigues Barbearia traz sua proposta de cortes e barbas de estilo premium para a Califórnia, em Nova Iguaçu. Uma identidade clássica, com a personalidade de quem faz do próprio visual uma assinatura.",
    servicesTitle: "Escolha seu próximo visual.",
    servicesLead: "Corte ou barba? Comece por aqui e combine os detalhes com a equipe.",
    bookingTitle: "Seu próximo horário\ncomeça aqui.",
    bookingLead: "Escolha o que deseja, informe sua preferência e envie a solicitação pelo WhatsApp. A equipe confirma os detalhes com você.",
    teamTitle: "Quem cuida da sua assinatura.",
    galleryTitle: "O estilo está nos detalhes.",
    galleryLead: "Conheça as categorias e acompanhe os registros da Dom Rodrigues no Instagram."
  },
  serviceCategories: [
    { id: "cortes", label: "Cortes" },
    { id: "barbas", label: "Barbas" }
  ],
  // Categorias gerais confirmadas pelo briefing. Detalhes e valores ainda sob consulta.
  services: [
    { id: "corte", category: "cortes", name: "Corte", description: "Seu estilo começa pela escolha do corte. Converse com a equipe sobre o visual que você procura.", price: null, durationMinutes: null, image: "", icon: "scissors", enabled: true },
    { id: "barba", category: "barbas", name: "Barba", description: "A barba também faz parte da sua assinatura. Consulte a equipe para definir os detalhes do atendimento.", price: null, durationMinutes: null, image: "", icon: "beard", enabled: true }
  ],
  // Somente profissionais reais, com autorização para divulgar nome/foto.
  // Exemplo de estrutura (não publicado):
  // {id:"id-unico", name:"NOME CONFIRMADO", specialties:["ESPECIALIDADE CONFIRMADA"], photo:"assets/fotos/profissional.webp", alt:"Retrato autorizado"}
  professionals: [],
  galleryCategories: [
    { id: "cortes", label: "Cortes" }, { id: "barbas", label: "Barbas" },
    { id: "resultados", label: "Resultados" }, { id: "ambiente", label: "Ambiente" }
  ],
  // Troque src:"" pelo caminho de uma foto autorizada. Sem foto = arte identificada.
  gallery: [
    {id:"cortes-01", category:"cortes", title:"Cortes com identidade", src:"", alt:"", placeholder:"cortes"},
    {id:"barbas-01", category:"barbas", title:"A assinatura da barba", src:"", alt:"", placeholder:"barbas"},
    {id:"resultados-01", category:"resultados", title:"Cada detalhe conta", src:"", alt:"", placeholder:"resultados"},
    {id:"ambiente-01", category:"ambiente", title:"O universo Dom Rodrigues", src:"", alt:"", placeholder:"ambiente"}
  ],
  // Apenas depoimentos verdadeiros e autorizados. Sem notas ou estrelas automáticas.
  // {name:"NOME AUTORIZADO", text:"DEPOIMENTO REAL", source:"ORIGEM CONFIRMADA"}
  testimonials: [],
  faq: [
    { question:"Como solicito um horário?", answer:"Preencha o formulário ou fale diretamente pelo WhatsApp. O site prepara sua mensagem; você revisa e envia no aplicativo. A solicitação só se torna um agendamento após a confirmação da equipe." },
    { question:"Os horários exibidos estão disponíveis?", answer:"O campo de horário registra apenas a sua preferência. Este site não consulta uma agenda em tempo real. Aguarde a equipe confirmar a data, o horário e o profissional." },
    { question:"Quais são os serviços e valores?", answer:"Cortes e barbas fazem parte da proposta da Dom Rodrigues. Consulte no WhatsApp os serviços específicos, valores e durações. O catálogo será atualizado com as informações confirmadas pela barbearia." },
    { question:"Quais formas de pagamento são aceitas?", answer:"Confirme as formas de pagamento diretamente com a equipe pelo WhatsApp antes do atendimento." },
    { question:"Onde fica a barbearia?", answer:"Na Rua Luiz Sobral, 492, Califórnia, Nova Iguaçu/RJ. Use o botão de rota na seção de localização para abrir o endereço no Google Maps." },
    { question:"Como consulto os horários de funcionamento?", answer:"Fale com a equipe pelo WhatsApp para confirmar o expediente e a disponibilidade para o dia desejado." }
  ]
};
