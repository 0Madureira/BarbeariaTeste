/* Site estático: sem banco, cookies, analytics ou persistência de dados pessoais. */
(() => {
  'use strict';
  const C = window.DOM_CONFIG;
  if (!C || !C.business) return;
  const B = C.business;
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const make = (tag, className, text) => {
    const n = document.createElement(tag);
    if (className) n.className = className;
    if (text !== undefined) n.textContent = text;
    return n;
  };
  const icons = new Set(['arrow','diagonal','whatsapp','pin','clock','calendar','instagram','share','person','check','scissors','beard','spark']);
  function icon(name, cls = 'icon') {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', cls); svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#i-' + (icons.has(name) ? name : 'spark')); svg.append(use);
    return svg;
  }
  const phone = String(B.whatsapp || '').replace(/\D/g, '');
  const phoneValid = /^55\d{10,11}$/.test(phone);
  const contactURL = 'https://wa.me/' + phone;
  const instagramURL = 'https://www.instagram.com/' + encodeURIComponent(String(B.instagram || '').replace(/^@/, '')) + '/';
  const mapsURL = /^https:\/\/(?:www\.)?(?:google\.com\/maps\/|maps\.app\.goo\.gl\/)/.test(B.mapsUrl || '') ? B.mapsUrl : 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(B.address);
  const contactMessage = 'Olá, Dom Rodrigues! Vim pelo site e gostaria de saber mais sobre os serviços e horários.';
  function externalLink(text, href, className) {
    const a = make('a', className, text); a.href = href; a.target = '_blank'; a.rel = 'noopener noreferrer'; return a;
  }
  function safeImagePath(src) {
    if (typeof src !== 'string' || !src.trim()) return '';
    if (/^(?:assets\/|\.\/assets\/)/.test(src) && !src.includes('..') && !/[<>"\x00-\x1f]/.test(src)) return src;
    return ''; // Arquivos locais mantêm o site independente de terceiros.
  }
  function photo(src, alt, fallback, cls = '') {
    const img = make('img', cls); img.src = safeImagePath(src) || fallback;
    img.alt = alt; img.loading = 'lazy'; img.decoding = 'async';
    img.addEventListener('error', () => {
      if (img.getAttribute('src') !== fallback) { img.src = fallback; img.alt = 'Imagem indisponível. ' + alt; }
    });
    return img;
  }
  $$('[data-contact]').forEach(a => { a.href = contactURL + '?text=' + encodeURIComponent(contactMessage); });
  $$('[data-instagram]').forEach(a => { a.href = instagramURL; if (a.classList.contains('menu-social')) a.firstChild.textContent = '@' + B.instagram + ' '; });
  $$('[data-maps]').forEach(a => { a.href = mapsURL; });
  $$('[data-phone]').forEach(n => { n.textContent = B.phoneDisplay; });
  $$('[data-logo]').forEach(n => { n.src = safeImagePath(B.logo) || 'assets/logo-referencia.webp'; n.alt = 'Logotipo ' + B.name; });
  $$('[data-address]').forEach(n => { n.replaceChildren(document.createTextNode(B.street), make('br'), document.createTextNode(B.neighborhood + ', ' + B.city + ' / ' + B.state)); });
  $$('[data-address-inline]').forEach(n => { n.textContent = B.address; });
  $$('[data-street]').forEach(n => { n.textContent = B.street; });
  $$('[data-text]').forEach(n => {
    const value = C.texts && C.texts[n.dataset.text]; if (typeof value !== 'string') return;
    n.replaceChildren(); value.split('\n').forEach((line, i) => { if (i) n.append(make('br')); n.append(document.createTextNode(line)); });
  });
  const year = $('#copyright-year'); if (year) year.textContent = String(new Date().getFullYear());
  const schema = $('#business-schema');
  if (schema) {
    const structured = {'@context':'https://schema.org','@type':'HairSalon',name:B.name,slogan:B.slogan,telephone:'+'+phone,address:{'@type':'PostalAddress',streetAddress:B.street+', '+B.neighborhood,addressLocality:B.city,addressRegion:B.state,addressCountry:'BR'},sameAs:[instagramURL]};
    if (/^https:\/\//.test(B.siteUrl || '')) structured.url = B.siteUrl.replace(/\/$/, '');
    schema.textContent = JSON.stringify(structured);
  }
  const hours = $('#opening-hours');
  if (hours && Array.isArray(B.hours) && B.hours.length) {
    hours.replaceChildren(...B.hours.map(h => { const row = make('div', 'hours-row'); row.append(make('span','',h.days),make('span','',h.time)); return row; }));
  }
  const heroVisual = $('#hero-visual');
  if (heroVisual && safeImagePath(B.heroImage)) {
    const img = $('.hero-art', heroVisual); const label = $('.placeholder-label', heroVisual);
    img.src = B.heroImage; img.alt = B.heroImageAlt || 'Dom Rodrigues Barbearia'; heroVisual.classList.add('has-photo');
    img.style.objectPosition = B.heroImagePosition || 'center'; label.textContent = 'DOM RODRIGUES · CALIFÓRNIA / RJ';
    img.addEventListener('error', () => { img.src = 'assets/hero-arte.svg'; img.alt = 'Ilustração de cadeira de barbearia; fotografia oficial ainda não disponível.'; heroVisual.classList.remove('has-photo'); label.textContent = 'ARTE ILUSTRATIVA · FOTO OFICIAL EM BREVE'; }, {once:true});
  }

  let toastTimer;
  function toast(message) {
    const n = $('#toast'); if (!n) return;
    n.textContent = message; n.hidden = false; clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { n.hidden = true; }, 5000);
  }
  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* alternativa local */ }
    }
    const t = make('textarea'); t.value = text; t.style.cssText = 'position:fixed;left:0;top:0;opacity:0;font-size:16px;'; document.body.append(t); t.focus(); t.select(); t.setSelectionRange(0,text.length);
    let ok = false; try { ok = document.execCommand('copy'); } catch (_) {} t.remove(); return ok;
  }

  // Menu: fechamento por link, Escape, mudança de largura e navegação por teclado.
  const menu = $('#mobile-menu'); const toggle = $('.menu-toggle');
  if (menu && toggle) {
    const inertTargets = ['main','.site-footer','.mobile-booking','.floating-whatsapp'].map(s => $(s)).filter(Boolean);
    function closeMenu(focus = false) {
      menu.hidden = true; toggle.setAttribute('aria-expanded','false'); toggle.setAttribute('aria-label','Abrir menu'); document.body.classList.remove('menu-open');
      inertTargets.forEach(n => { n.inert = false; }); if (focus) toggle.focus();
    }
    toggle.addEventListener('click', () => {
      if (!menu.hidden) { closeMenu(true); return; }
      menu.hidden = false; toggle.setAttribute('aria-expanded','true'); toggle.setAttribute('aria-label','Fechar menu'); document.body.classList.add('menu-open');
      inertTargets.forEach(n => { n.inert = true; }); $('a', menu).focus();
    });
    $$('a', menu).forEach(a => a.addEventListener('click', () => closeMenu(false)));
    document.addEventListener('keydown', e => {
      if (menu.hidden) return;
      if (e.key === 'Escape') { e.preventDefault(); closeMenu(true); }
      if (e.key === 'Tab') {
        const items = [toggle,...$$('a,button',menu)]; const i = items.indexOf(document.activeElement);
        if (e.shiftKey && i === 0) { e.preventDefault(); items[items.length-1].focus(); }
        else if (!e.shiftKey && i === items.length-1) { e.preventDefault(); toggle.focus(); }
      }
    });
    window.addEventListener('resize', () => { if (window.innerWidth > 900 && !menu.hidden) closeMenu(); });
    window.addEventListener('pageshow', () => closeMenu());
  }

  // Filtragem com botões semânticos e estado selecionado anunciado.
  function filters(root, categories, onChange) {
    if (!root) return;
    const all = [{id:'todos',label:'Todos'},...categories];
    root.replaceChildren(...all.map((cat, i) => {
      const b = make('button','filter-button',cat.label); b.type='button'; b.dataset.category=cat.id; b.setAttribute('aria-pressed',i===0?'true':'false');
      b.addEventListener('click',() => { $$('button',root).forEach(x => x.setAttribute('aria-pressed',x===b?'true':'false')); onChange(cat.id); }); return b;
    }));
  }
  const services = (C.services || []).filter(s => s && s.enabled !== false);
  const professionals = (C.professionals || []).filter(p => p && p.id && p.name);
  const serviceSelect = $('#booking-service');
  if (serviceSelect) {
    services.forEach(s => { const option = make('option','',s.name); option.value=String(s.id); serviceSelect.append(option); });
    const option = make('option','','Quero orientação da equipe'); option.value='orientacao'; serviceSelect.append(option);
  }
  const proField = $('#professional-field');
  if (proField && professionals.length) {
    const old = $('#booking-professional'); const select = make('select'); select.id=old.id; select.name='professional'; select.setAttribute('aria-describedby','professional-hint professional-error');
    const base=make('option','','Sem preferência');base.value='';select.append(base);
    professionals.forEach(p => { const o=make('option','',p.name);o.value=p.id;select.append(o); });old.replaceWith(select);
    $('#professional-hint').textContent='A disponibilidade do profissional será confirmada pela equipe.';
  }
  function chooseBooking(serviceId, professionalId) {
    if (serviceSelect && serviceId) serviceSelect.value = serviceId;
    if (professionalId) { const input=$('#booking-professional'); if(input) input.value=professionalId; }
    const section=$('#agendamento');
    if (section) section.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    const msg = serviceId ? 'Serviço selecionado. Preencha seus dados para solicitar um horário.' : 'Profissional selecionado. Complete sua solicitação.';
    toast(msg);
    // Move o foco sem abrir o teclado virtual automaticamente.
    const title=$('#booking-title'); if(title){ title.tabIndex=-1;title.focus({preventScroll:true}); }
  }
  function renderServices(category='todos') {
    const root=$('#service-grid');if(!root)return;
    const list=services.filter(s=>category==='todos'||s.category===category);
    root.replaceChildren();
    if(!list.length){const empty=make('div','empty-card','Serviços desta categoria ainda não publicados. Consulte a equipe.');empty.append(externalLink('Conversar no WhatsApp',contactURL,'text-link'));root.append(empty);return;}
    list.forEach(s=>{
      const card=make('article','service-card');const top=make('div','service-top');
      top.append(make('span','service-number',String(services.indexOf(s)+1).padStart(2,'0')+' / '+((C.serviceCategories||[]).find(c=>c.id===s.category)?.label||'SERVIÇO').toUpperCase()),icon(s.icon||'spark','service-icon'));
      card.append(top);
      if(safeImagePath(s.image))card.append(photo(s.image,s.name,'assets/galeria-cortes.svg','service-photo'));
      card.append(make('h3','',s.name),make('p','',s.description||'Consulte os detalhes com a equipe.'));
      const meta=make('div','service-meta'),price=make('div','service-price');
      const hasPrice=typeof s.price==='number'&&Number.isFinite(s.price)&&s.price>=0;
      price.append(make('strong','',hasPrice?new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(s.price):'Valores sob consulta'));
      price.append(make('span','',typeof s.durationMinutes==='number'&&s.durationMinutes>0?s.durationMinutes+' min · estimativa':'Duração sob consulta'));
      const button=make('button','service-book');button.type='button';button.setAttribute('aria-label','Solicitar horário para '+s.name);button.append(icon('diagonal'));button.addEventListener('click',()=>chooseBooking(s.id));
      meta.append(price,button);card.append(meta);root.append(card);
    });
  }
  filters($('#service-filters'),C.serviceCategories||[],renderServices);renderServices();

  // Profissionais: nenhum perfil fictício.
  const team=$('#team-grid');
  if(team){
    if(!professionals.length){
      const empty=make('div','team-empty');const symbol=make('span','team-symbol');symbol.append(icon('person'));
      const copy=make('div','team-empty-copy');copy.append(make('h3','','Seu atendimento, com a equipe Dom.'),make('p','','Já tem um profissional de preferência? Conte para a equipe no WhatsApp. Os perfis serão publicados após a confirmação das informações.'));
      const a=externalLink('Falar com a equipe',contactURL+'?text='+encodeURIComponent('Olá! Gostaria de conhecer os profissionais da Dom Rodrigues e solicitar um horário.'),'text-link');a.append(icon('arrow'));empty.append(symbol,copy,a);team.append(empty);
    }else professionals.forEach(p=>{
      const card=make('article','team-card');
      if(safeImagePath(p.photo))card.append(photo(p.photo,p.alt||'Retrato de '+p.name,'assets/profissional-placeholder.svg','team-photo'));
      else{const ph=make('div','team-photo-placeholder');ph.append(icon('person'),make('span','','FOTO OFICIAL EM BREVE'));card.append(ph);}
      card.append(make('h3','',p.name));if(Array.isArray(p.specialties)&&p.specialties.length)card.append(make('p','',p.specialties.join(' · ')));
      const button=make('button','text-link','Solicitar horário');button.type='button';button.append(icon('arrow'));button.addEventListener('click',()=>chooseBooking(null,p.id));card.append(button);team.append(card);
    });
  }

  // Galeria: imagens locais, filtros, teclado, toque e fechamento acessível.
  const gallery=(C.gallery||[]).filter(g=>g&&g.id);
  let shownGallery=[...gallery],galleryIndex=0,lastGalleryFocus=null;
  const galleryDialog=$('#gallery-dialog');
  function galleryPath(g){return safeImagePath(g.src)||'assets/galeria-'+(['cortes','barbas','resultados','ambiente'].includes(g.placeholder||g.category)?(g.placeholder||g.category):'resultados')+'.svg';}
  function isOfficial(g){return Boolean(safeImagePath(g.src));}
  function updateLightbox(){
    const g=shownGallery[galleryIndex];if(!g||!galleryDialog)return;
    const img=$('#lightbox-image');img.src=galleryPath(g);img.alt=isOfficial(g)?(g.alt||g.title):'Arte ilustrativa. Espaço reservado para fotografia oficial: '+g.title;
    img.onerror=()=>{img.onerror=null;img.src='assets/galeria-'+(['cortes','barbas','resultados','ambiente'].includes(g.category)?g.category:'resultados')+'.svg';$('#lightbox-caption').textContent='A fotografia não pôde ser carregada. Arte ilustrativa de substituição.';};
    $('#lightbox-title').textContent=g.title;$('#lightbox-count').textContent=String(galleryIndex+1).padStart(2,'0')+' / '+String(shownGallery.length).padStart(2,'0');
    $('#lightbox-caption').textContent=isOfficial(g)?(g.caption||'Registro da Dom Rodrigues Barbearia.'):'ARTE ILUSTRATIVA · espaço reservado para fotografia oficial autorizada.';
    $('#gallery-prev').hidden=shownGallery.length<2;$('#gallery-next').hidden=shownGallery.length<2;
  }
  function openGallery(index,trigger){
    if(!galleryDialog||!shownGallery.length)return;galleryIndex=index;lastGalleryFocus=trigger;updateLightbox();galleryDialog.showModal();document.body.classList.add('dialog-open');$('#close-gallery').focus();
  }
  function stepGallery(direction){galleryIndex=(galleryIndex+direction+shownGallery.length)%shownGallery.length;updateLightbox();}
  function renderGallery(category='todos'){
    const root=$('#gallery-grid');if(!root)return;shownGallery=gallery.filter(g=>category==='todos'||g.category===category);root.replaceChildren();
    if(!shownGallery.length){const n=make('div','empty-card','Ainda não há imagens nesta categoria. Acompanhe a Dom Rodrigues no Instagram.');n.append(externalLink('Abrir Instagram',instagramURL,'text-link'));root.append(n);return;}
    shownGallery.forEach((g,index)=>{
      const b=make('button','gallery-item');b.type='button';b.setAttribute('aria-label','Ampliar '+g.title+(isOfficial(g)?'':' — arte ilustrativa, foto oficial em breve'));
      const img=photo(g.src,isOfficial(g)?(g.alt||g.title):'Arte ilustrativa de '+g.category+'. Fotografia oficial ainda não publicada.',galleryPath({...g,src:''}));img.width=600;img.height=800;
      const info=make('span','gallery-info');info.append(make('strong','',g.title),make('small','',isOfficial(g)?'DOM RODRIGUES':'ARTE ILUSTRATIVA · FOTO EM BREVE'));
      b.append(img,make('span','gallery-zoom','+'),info);b.addEventListener('click',()=>openGallery(index,b));root.append(b);
    });
    const foot=$('.gallery-footer p');if(foot&&gallery.every(isOfficial))foot.textContent='Registros da Dom Rodrigues. Acompanhe mais no Instagram.';
  }
  filters($('#gallery-filters'),C.galleryCategories||[],renderGallery);renderGallery();
  if(galleryDialog){
    $('#close-gallery').addEventListener('click',()=>galleryDialog.close());$('#gallery-prev').addEventListener('click',()=>stepGallery(-1));$('#gallery-next').addEventListener('click',()=>stepGallery(1));
    galleryDialog.addEventListener('click',e=>{if(e.target===galleryDialog){const r=galleryDialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)galleryDialog.close();}});
    galleryDialog.addEventListener('close',()=>{document.body.classList.remove('dialog-open');lastGalleryFocus?.focus();});
    galleryDialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();stepGallery(1);}if(e.key==='ArrowLeft'){e.preventDefault();stepGallery(-1);}});
    let touchStart=null;const stage=$('#lightbox-stage');
    stage.addEventListener('touchstart',e=>{if(e.touches.length===1)touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY};else touchStart=null;},{passive:true});
    stage.addEventListener('touchend',e=>{if(!touchStart||!e.changedTouches.length)return;const dx=e.changedTouches[0].clientX-touchStart.x,dy=e.changedTouches[0].clientY-touchStart.y;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.4)stepGallery(dx<0?1:-1);touchStart=null;},{passive:true});
  }

  const testimonyRoot=$('#testimonials-content');
  if(testimonyRoot){
    const entries=(C.testimonials||[]).filter(t=>t&&t.name&&t.text);
    if(!entries.length){const div=make('div','testimonial-empty');div.append(make('span','','“'),make('p','','Cada cliente tem uma história com seu visual. Os depoimentos serão publicados aqui com autorização.'),make('small','','DEPOIMENTOS AINDA NÃO PUBLICADOS'));const a=externalLink('Acompanhar a Dom no Instagram',instagramURL,'text-link');a.append(icon('diagonal'));div.append(a);testimonyRoot.append(div);}
    else entries.forEach(t=>{const q=make('blockquote','',t.text);q.append(make('cite','',t.name+(t.source?' · '+t.source:'')));testimonyRoot.append(q);});
  }
  const faq=$('#faq-list');
  if(faq)(C.faq||[]).forEach(f=>{const d=make('details','faq-item');d.append(make('summary','',f.question),make('p','',f.answer));faq.append(d);});

  // Formulário. Os dados só existem no DOM/memória e na mensagem que o cliente enviar.
  const form=$('#booking-form');let preparedMessage='';
  function todayInBrazil(){
    const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
    return ['year','month','day'].map(k=>parts.find(p=>p.type===k).value).join('-');
  }
  const tidy=s=>String(s||'').trim().replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ');
  function validateDate(value){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return null;
    const [y,m,d]=value.split('-').map(Number);if(y<1900||y>9999)return null;
    const date=new Date(Date.UTC(y,m-1,d,12));return date.getUTCFullYear()===y&&date.getUTCMonth()===m-1&&date.getUTCDate()===d?date:null;
  }
  function clearPrepared(){
    preparedMessage='';const fb=$('#message-fallback');if(fb)fb.hidden=true;const pre=$('#message-preview');if(pre)pre.textContent='';const a=$('#whatsapp-prepared');if(a)a.href=contactURL;
  }
  if(form){
    const dateInput=$('#booking-date'),timeInput=$('#booking-time');dateInput.min=todayInBrazil();
    form.addEventListener('focusin',()=>document.body.classList.add('form-focused'));
    form.addEventListener('focusout',()=>setTimeout(()=>{if(!form.contains(document.activeElement))document.body.classList.remove('form-focused');},0));
    const fieldMap={name:'customer-name',service:'booking-service',professional:'booking-professional',date:'booking-date',time:'booking-time',notes:'booking-notes'};
    function error(key,message){const input=$('#'+fieldMap[key]);const output=$('#'+key+'-error');input.setAttribute('aria-invalid',message?'true':'false');output.textContent=message;}
    form.addEventListener('input',e=>{clearPrepared();$('#form-status').textContent='';const key=Object.keys(fieldMap).find(k=>fieldMap[k]===e.target.id);if(key)error(key,'');});
    form.addEventListener('change',()=>{clearPrepared();$('#form-status').textContent='';});
    window.addEventListener('pageshow',()=>{dateInput.min=todayInBrazil();});
    form.addEventListener('submit',e=>{
      e.preventDefault();clearPrepared();Object.keys(fieldMap).forEach(k=>error(k,''));
      const name=tidy($('#customer-name').value),serviceId=serviceSelect.value,proInput=$('#booking-professional'),proValue=tidy(proInput.value),date=dateInput.value,time=timeInput.value,notes=tidy($('#booking-notes').value);
      const chosenService=services.find(s=>String(s.id)===serviceId);const serviceName=chosenService?chosenService.name:serviceId==='orientacao'?'Orientação da equipe':'';
      const pro=professionals.length?(professionals.find(p=>p.id===proValue)?.name||'Sem preferência'):(proValue||'Sem preferência');
      const errors=[];const add=(key,message)=>{error(key,message);errors.push(key);};
      if(name.length<2||name.length>80||!/[\p{L}]/u.test(name))add('name','Informe seu nome, com 2 a 80 caracteres.');
      if(!serviceName)add('service','Escolha um serviço ou peça orientação.');
      if(proValue.length>60)add('professional','Use até 60 caracteres para a preferência.');
      const parsed=validateDate(date);const today=todayInBrazil();
      if(!parsed)add('date','Informe uma data válida.');else if(date<today)add('date','Escolha hoje ou uma data futura.');
      if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time))add('time','Informe um horário válido.');
      else if(parsed&&date===today){const current=new Intl.DateTimeFormat('en-GB',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date());if(time<=current)add('time','Para hoje, escolha um horário que ainda não passou.');}
      if(notes.length>500)add('notes','Use até 500 caracteres nas observações.');
      if(errors.length){$('#form-status').textContent='Revise os campos indicados para continuar.';$('#'+fieldMap[errors[0]]).focus();return;}
      if(!phoneValid){$('#form-status').textContent='O contato precisa ser atualizado. Use o Instagram para falar com a barbearia.';return;}
      const formatted=new Intl.DateTimeFormat('pt-BR',{timeZone:'UTC',weekday:'long',day:'2-digit',month:'2-digit',year:'numeric'}).format(parsed);
      preparedMessage=['Olá, Dom Rodrigues! Vim pelo site e gostaria de solicitar um horário.','','*SOLICITAÇÃO DE AGENDAMENTO*','Nome: '+name,'Serviço: '+serviceName,'Profissional de preferência: '+pro,'Data desejada: '+formatted,'Horário desejado: '+time,...(notes?['Observações: '+notes]:[]),'','Entendo que esta é uma solicitação e que o horário depende de confirmação da equipe.'].join('\n');
      const url=contactURL+'?text='+encodeURIComponent(preparedMessage);$('#whatsapp-prepared').href=url;$('#message-preview').textContent=preparedMessage;$('#message-fallback').hidden=false;
      $('#form-status').textContent='Mensagem preparada. Revise e envie no WhatsApp. Seu horário ainda depende de confirmação.';
      // Abertura síncrona na ação do usuário. O link permanece como alternativa a bloqueadores.
      window.open(url,'_blank','noopener,noreferrer');
    });
    $('#copy-booking').addEventListener('click',async()=>{if(!preparedMessage)return;toast(await copyText(preparedMessage)?'Mensagem copiada. Cole no WhatsApp e envie.':'Selecione o texto em “Revisar mensagem preparada” para copiar.');});
  }

  // Web Share API; fallback por cópia, sem serviço de terceiros.
  const shareButton=$('#share-site'),shareDialog=$('#share-dialog');
  if(shareButton&&shareDialog){
    shareButton.addEventListener('click',async()=>{
      const configured=/^https:\/\//.test(B.siteUrl||'')?B.siteUrl.replace(/\/$/,'')+'/':null;
      const url=configured||(/^https?:$/.test(location.protocol)?location.origin+location.pathname:'');
      if(!url){toast('Publique o site para compartilhar um link público.');return;}
      const data={title:B.name,text:B.slogan,url};
      if(navigator.share){try{await navigator.share(data);return;}catch(err){if(err.name==='AbortError')return;}}
      $('#share-url').value=url;shareDialog.showModal();document.body.classList.add('dialog-open');$('#copy-share').focus();
    });
    $('.close-share',shareDialog).addEventListener('click',()=>shareDialog.close());
    shareDialog.addEventListener('close',()=>{document.body.classList.remove('dialog-open');shareButton.focus();});
    $('#copy-share').addEventListener('click',async()=>{const success=await copyText($('#share-url').value);if(success){shareDialog.close();toast('Link copiado. Compartilhe a Dom Rodrigues.');}else{$('#share-url').focus();$('#share-url').select();toast('Selecione e copie o link exibido.');}});
  }

  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  if('IntersectionObserver' in window&&!reduced.matches){
    const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}});},{threshold:.06,rootMargin:'0px 0px 10px 0px'});
    document.documentElement.classList.add('motion-ready');$$('.reveal').forEach(n=>observer.observe(n));
    // Âncoras e alterações de preferência nunca devem deixar conteúdo escondido.
    reduced.addEventListener?.('change',e=>{if(e.matches)document.documentElement.classList.remove('motion-ready');});
  }
})();
