# Dom Rodrigues Barbearia — sistema web

Aplicação com frontend HTML/CSS/JavaScript, API Cloudflare Worker, D1, arquivos R2 e adaptador local SQLite. A identidade, as fontes, o logotipo e as artes do ZIP original foram preservados. Não é uma agenda em localStorage.

## Iniciar localmente

Node.js 24 ou superior, sem dependências npm para executar a aplicação e os testes:

```bash
npm run dev
```

Abra `http://localhost:3000`. O ambiente local é demonstrativo por padrão. Use os botões do aviso superior para entrar como Rodrigues ou cliente de teste. A criação dos dados exige essa ação explícita. Banco e uploads ficam em `.data/`, fora do código versionado. Atualizar a página não apaga os registros.

```bash
npm test
npm run check
npm run build
```

## Conteúdo

| Pasta | Conteúdo |
|---|---|
| `public/` | Site, painel e área do cliente responsivos |
| `backend/` | API, autenticação, regras, provedores e dados de demonstração |
| `db/migrations/` | Migrações SQL append-only, índices e guardas transacionais |
| `scripts/` | Execução local, migração, empacotamento e verificação |
| `tests/` | Testes de integração usando o mesmo Worker com SQLite real |
| `docs/` | Implantação, operação, testes, custos e pendências |
| `original/` | Site recebido, preservado como referência |

## Segurança e ativação

Não há senha padrão. Produção exige segredo de autenticação, administrador exclusivo e verificação oficial de telefone. A demonstração hospedada é privada e possui duas entradas próprias, bloqueadas quando `DEMO_MODE=false`. Nunca torne o ambiente de demonstração público nem use dados reais nele.

As integrações Asaas e WhatsApp estão implementadas e bloqueadas sem configuração. Testes automatizados usam respostas controladas de provedor, sem se passar por uma homologação real. Não houve envio, cobrança real ou publicação comercial.

Leia [Implantação](docs/IMPLANTACAO.md), [Manual do Rodrigues](docs/MANUAL_RODRIGUES.md), [Relatório de testes](docs/TESTES.md), [Pendências externas](docs/PENDENCIAS.md) e [Custos](docs/CUSTOS.md).
