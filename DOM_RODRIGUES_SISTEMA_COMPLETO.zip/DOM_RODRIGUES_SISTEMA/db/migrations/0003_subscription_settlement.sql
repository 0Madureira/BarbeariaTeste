ALTER TABLE subscription_payments ADD COLUMN settled INTEGER NOT NULL DEFAULT 0 CHECK(settled IN(0,1));
