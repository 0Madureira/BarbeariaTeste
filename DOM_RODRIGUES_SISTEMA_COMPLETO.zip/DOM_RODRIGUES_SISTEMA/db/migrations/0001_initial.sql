PRAGMA foreign_keys = ON;
--> statement-breakpoint
CREATE TABLE settings (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1);
--> statement-breakpoint
CREATE TABLE users (id TEXT PRIMARY KEY, role TEXT NOT NULL CHECK(role IN ('admin','customer')), name TEXT NOT NULL, phone TEXT NOT NULL UNIQUE, password_hash TEXT, verified INTEGER NOT NULL DEFAULT 0 CHECK(verified IN(0,1)), active INTEGER NOT NULL DEFAULT 1, consent_service INTEGER NOT NULL DEFAULT 0, consent_marketing INTEGER NOT NULL DEFAULT 0, consent_at INTEGER, provider_customer_id TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE UNIQUE INDEX only_rodrigues_admin ON users(role) WHERE role='admin';
--> statement-breakpoint
CREATE TABLE sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), csrf TEXT NOT NULL, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE INDEX sessions_user ON sessions(user_id);
--> statement-breakpoint
CREATE TABLE challenges (id TEXT PRIMARY KEY, phone TEXT NOT NULL, purpose TEXT NOT NULL CHECK(purpose IN('verify','recover')), code_hash TEXT NOT NULL, expires_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, consumed INTEGER NOT NULL DEFAULT 0);
--> statement-breakpoint
CREATE TABLE rate_limits (id TEXT PRIMARY KEY, hits INTEGER NOT NULL, expires_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE services (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', category TEXT NOT NULL, price_cents INTEGER NOT NULL CHECK(price_cents>=0), duration_minutes INTEGER NOT NULL CHECK(duration_minutes BETWEEN 5 AND 240 AND duration_minutes%5=0), active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0, version INTEGER NOT NULL DEFAULT 1);
--> statement-breakpoint
CREATE TABLE barbers (id TEXT PRIMARY KEY, name TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '', photo_key TEXT, active INTEGER NOT NULL DEFAULT 1, online INTEGER NOT NULL DEFAULT 0, is_owner INTEGER NOT NULL DEFAULT 0, commission_bps INTEGER NOT NULL DEFAULT 4000 CHECK(commission_bps BETWEEN 0 AND 10000), version INTEGER NOT NULL DEFAULT 1);
--> statement-breakpoint
CREATE UNIQUE INDEX only_owner_barber ON barbers(is_owner) WHERE is_owner=1;
--> statement-breakpoint
CREATE TABLE barber_services (barber_id TEXT NOT NULL REFERENCES barbers(id), service_id TEXT NOT NULL REFERENCES services(id), PRIMARY KEY(barber_id,service_id));
--> statement-breakpoint
CREATE TABLE weekly_hours (id TEXT PRIMARY KEY, barber_id TEXT NOT NULL REFERENCES barbers(id), weekday INTEGER NOT NULL CHECK(weekday BETWEEN 0 AND 6), start_minute INTEGER NOT NULL CHECK(start_minute>=0), end_minute INTEGER NOT NULL CHECK(end_minute<=1440 AND end_minute>start_minute));
--> statement-breakpoint
CREATE INDEX weekly_barber ON weekly_hours(barber_id,weekday);
--> statement-breakpoint
CREATE TABLE special_hours (id TEXT PRIMARY KEY, barber_id TEXT NOT NULL REFERENCES barbers(id), day TEXT NOT NULL, start_minute INTEGER NOT NULL CHECK(start_minute>=0), end_minute INTEGER NOT NULL CHECK(end_minute<=1440 AND end_minute>start_minute));
--> statement-breakpoint
CREATE TABLE blocks (id TEXT PRIMARY KEY, barber_id TEXT REFERENCES barbers(id), starts_at INTEGER NOT NULL, ends_at INTEGER NOT NULL CHECK(ends_at>starts_at), reason TEXT NOT NULL, created_by TEXT REFERENCES users(id));
--> statement-breakpoint
CREATE INDEX blocks_time ON blocks(starts_at,ends_at,barber_id);
--> statement-breakpoint
CREATE TABLE plans (id TEXT PRIMARY KEY,name TEXT NOT NULL,price_cents INTEGER NOT NULL CHECK(price_cents>0),active INTEGER NOT NULL DEFAULT 1,for_sale INTEGER NOT NULL DEFAULT 0,provisional INTEGER NOT NULL DEFAULT 1,version INTEGER NOT NULL DEFAULT 1);
--> statement-breakpoint
CREATE TABLE plan_services (plan_id TEXT NOT NULL REFERENCES plans(id),service_id TEXT NOT NULL REFERENCES services(id),PRIMARY KEY(plan_id,service_id));
--> statement-breakpoint
CREATE TABLE subscriptions (id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),plan_id TEXT NOT NULL REFERENCES plans(id),plan_name TEXT NOT NULL,price_cents INTEGER NOT NULL CHECK(price_cents>0),status TEXT NOT NULL CHECK(status IN('pending','active','past_due','cancelled')),valid_until INTEGER NOT NULL DEFAULT 0,cancel_at_end INTEGER NOT NULL DEFAULT 0,provider_id TEXT UNIQUE,checkout_id TEXT,checkout_url TEXT,provider_mode TEXT NOT NULL CHECK(provider_mode IN('sandbox','production','demo')),request_key TEXT NOT NULL UNIQUE,created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE UNIQUE INDEX subscription_current ON subscriptions(user_id) WHERE status IN('pending','active','past_due');
--> statement-breakpoint
CREATE TABLE subscription_services (subscription_id TEXT NOT NULL REFERENCES subscriptions(id),service_id TEXT NOT NULL REFERENCES services(id),PRIMARY KEY(subscription_id,service_id));
--> statement-breakpoint
CREATE TABLE subscription_payments (id TEXT PRIMARY KEY,subscription_id TEXT NOT NULL REFERENCES subscriptions(id),provider_payment_id TEXT NOT NULL UNIQUE,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),status TEXT NOT NULL CHECK(status IN('confirmed','refunded','overdue')),paid_at INTEGER NOT NULL,period_end INTEGER NOT NULL,provider_mode TEXT NOT NULL);
--> statement-breakpoint
CREATE TABLE webhook_events (id TEXT PRIMARY KEY,provider TEXT NOT NULL,event_type TEXT NOT NULL,received_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'processed');
--> statement-breakpoint
CREATE TABLE appointments (id TEXT PRIMARY KEY,customer_id TEXT NOT NULL REFERENCES users(id),barber_id TEXT NOT NULL REFERENCES barbers(id),service_id TEXT NOT NULL REFERENCES services(id),starts_at INTEGER NOT NULL,ends_at INTEGER NOT NULL CHECK(ends_at>starts_at),local_day TEXT NOT NULL,start_minute INTEGER NOT NULL,end_minute INTEGER NOT NULL,service_name TEXT NOT NULL,barber_name TEXT NOT NULL,price_cents INTEGER NOT NULL CHECK(price_cents>=0),duration_minutes INTEGER NOT NULL,commission_bps INTEGER NOT NULL CHECK(commission_bps BETWEEN 0 AND 10000),owner_snapshot INTEGER NOT NULL DEFAULT 0,subscription_id TEXT REFERENCES subscriptions(id),status TEXT NOT NULL DEFAULT 'booked' CHECK(status IN('booked','waiting','in_service','completed','cancelled','no_show')),charged_cents INTEGER CHECK(charged_cents>=0),discount_reason TEXT,notes TEXT NOT NULL DEFAULT '',admin_override INTEGER NOT NULL DEFAULT 0,request_key TEXT NOT NULL,request_fingerprint TEXT NOT NULL,checked_in_at INTEGER,completed_at INTEGER,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,UNIQUE(customer_id,request_key));
--> statement-breakpoint
CREATE INDEX appointments_barber_time ON appointments(barber_id,starts_at,ends_at,status);
--> statement-breakpoint
CREATE INDEX appointments_customer_time ON appointments(customer_id,starts_at,status);
--> statement-breakpoint
CREATE INDEX appointments_day ON appointments(local_day,status);
--> statement-breakpoint
CREATE TABLE commissions (id TEXT PRIMARY KEY,appointment_id TEXT NOT NULL UNIQUE REFERENCES appointments(id),barber_id TEXT NOT NULL REFERENCES barbers(id),base_cents INTEGER NOT NULL,barber_cents INTEGER NOT NULL CHECK(barber_cents>=0),house_cents INTEGER NOT NULL CHECK(house_cents>=0),bps_snapshot INTEGER NOT NULL,kind TEXT NOT NULL CHECK(kind IN('single','subscription_pending')),created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE receipts (id TEXT PRIMARY KEY,appointment_id TEXT NOT NULL REFERENCES appointments(id),amount_cents INTEGER NOT NULL CHECK(amount_cents>0),method TEXT NOT NULL,received_at INTEGER NOT NULL,request_key TEXT NOT NULL UNIQUE,created_by TEXT NOT NULL REFERENCES users(id));
--> statement-breakpoint
CREATE TABLE refunds (id TEXT PRIMARY KEY,receipt_id TEXT NOT NULL REFERENCES receipts(id),amount_cents INTEGER NOT NULL CHECK(amount_cents>0),barber_adjustment_cents INTEGER NOT NULL CHECK(barber_adjustment_cents>=0),reason TEXT NOT NULL,created_at INTEGER NOT NULL,created_by TEXT NOT NULL REFERENCES users(id),request_key TEXT NOT NULL UNIQUE);
--> statement-breakpoint
CREATE TABLE payouts (id TEXT PRIMARY KEY,barber_id TEXT NOT NULL REFERENCES barbers(id),amount_cents INTEGER NOT NULL CHECK(amount_cents>0),method TEXT NOT NULL,paid_at INTEGER NOT NULL,receipt_key TEXT,notes TEXT NOT NULL DEFAULT '',request_key TEXT NOT NULL UNIQUE,created_by TEXT NOT NULL REFERENCES users(id));
--> statement-breakpoint
CREATE TABLE payout_allocations (payout_id TEXT NOT NULL REFERENCES payouts(id),commission_id TEXT NOT NULL REFERENCES commissions(id),amount_cents INTEGER NOT NULL CHECK(amount_cents>0),PRIMARY KEY(payout_id,commission_id));
--> statement-breakpoint
CREATE TABLE expenses (id TEXT PRIMARY KEY,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),category TEXT NOT NULL,description TEXT NOT NULL,method TEXT NOT NULL,occurred_at INTEGER NOT NULL,created_by TEXT NOT NULL REFERENCES users(id),reversal_of TEXT UNIQUE REFERENCES expenses(id),request_key TEXT NOT NULL UNIQUE);
--> statement-breakpoint
CREATE TABLE cash_sessions (id TEXT PRIMARY KEY,day TEXT NOT NULL UNIQUE,opening_cents INTEGER NOT NULL CHECK(opening_cents>=0),counted_cents INTEGER CHECK(counted_cents>=0),expected_cents INTEGER,notes TEXT NOT NULL DEFAULT '',opened_at INTEGER NOT NULL,closed_at INTEGER,created_by TEXT NOT NULL REFERENCES users(id));
--> statement-breakpoint
CREATE TABLE notifications (id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),kind TEXT NOT NULL,entity_id TEXT NOT NULL,dedupe_key TEXT NOT NULL UNIQUE,payload TEXT NOT NULL DEFAULT '{}',status TEXT NOT NULL CHECK(status IN('pending','processing','sent','delivered','failed','unconfigured','cancelled','unknown')),attempts INTEGER NOT NULL DEFAULT 0,provider_id TEXT UNIQUE,next_attempt_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,last_error TEXT,claim_token TEXT);
--> statement-breakpoint
CREATE INDEX notification_queue ON notifications(status,next_attempt_at);
--> statement-breakpoint
CREATE TABLE uploads (id TEXT PRIMARY KEY,object_key TEXT NOT NULL UNIQUE,mime TEXT NOT NULL,size_bytes INTEGER NOT NULL,purpose TEXT NOT NULL CHECK(purpose IN('barber','receipt')),created_by TEXT NOT NULL REFERENCES users(id),created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE audit_log (id TEXT PRIMARY KEY,actor_id TEXT REFERENCES users(id),action TEXT NOT NULL,entity_id TEXT,details TEXT NOT NULL DEFAULT '{}',created_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE INDEX audit_created ON audit_log(created_at);
--> statement-breakpoint
CREATE TABLE guards (id TEXT PRIMARY KEY,ok INTEGER NOT NULL CHECK(ok=1));
--> statement-breakpoint
CREATE TRIGGER appointment_insert_guard BEFORE INSERT ON appointments BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.customer_id AND role='customer' AND active=1 AND verified=1) THEN RAISE(ABORT,'CUSTOMER_UNVERIFIED') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM barbers b JOIN barber_services bs ON bs.barber_id=b.id JOIN services s ON s.id=bs.service_id WHERE b.id=NEW.barber_id AND bs.service_id=NEW.service_id AND b.active=1 AND (b.online=1 OR NEW.admin_override=1) AND s.active=1 AND s.duration_minutes=NEW.duration_minutes AND s.price_cents=NEW.price_cents AND b.commission_bps=NEW.commission_bps AND b.is_owner=NEW.owner_snapshot) THEN RAISE(ABORT,'CATALOG_CHANGED') END;
 SELECT CASE WHEN NEW.ends_at-NEW.starts_at<>NEW.duration_minutes*60 OR NEW.end_minute-NEW.start_minute<>NEW.duration_minutes THEN RAISE(ABORT,'DURATION_INVALID') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM weekly_hours w WHERE w.barber_id=NEW.barber_id AND w.weekday=CAST(strftime('%w',NEW.local_day) AS INTEGER) AND w.start_minute<=NEW.start_minute AND w.end_minute>=NEW.end_minute AND NOT EXISTS(SELECT 1 FROM special_hours h WHERE h.barber_id=NEW.barber_id AND h.day=NEW.local_day)) AND NOT EXISTS(SELECT 1 FROM special_hours h WHERE h.barber_id=NEW.barber_id AND h.day=NEW.local_day AND h.start_minute<=NEW.start_minute AND h.end_minute>=NEW.end_minute) THEN RAISE(ABORT,'OUTSIDE_HOURS') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM appointments a WHERE a.barber_id=NEW.barber_id AND a.status NOT IN('cancelled','no_show') AND a.starts_at<NEW.ends_at AND a.ends_at>NEW.starts_at) THEN RAISE(ABORT,'SLOT_CONFLICT') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM blocks b WHERE (b.barber_id=NEW.barber_id OR b.barber_id IS NULL) AND b.starts_at<NEW.ends_at AND b.ends_at>NEW.starts_at) THEN RAISE(ABORT,'BLOCKED') END;
 SELECT CASE WHEN NEW.admin_override=0 AND (SELECT COUNT(*) FROM appointments a WHERE a.customer_id=NEW.customer_id AND a.status IN('booked','waiting','in_service') AND a.ends_at>unixepoch())>=COALESCE((SELECT json_extract(value,'$.max_future_bookings') FROM settings WHERE id=1),1) THEN RAISE(ABORT,'FUTURE_LIMIT') END;
 SELECT CASE WHEN NEW.subscription_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM subscriptions sub JOIN subscription_services ss ON ss.subscription_id=sub.id WHERE sub.id=NEW.subscription_id AND sub.user_id=NEW.customer_id AND sub.status IN('active','cancelled') AND sub.valid_until>=NEW.ends_at AND ss.service_id=NEW.service_id) THEN RAISE(ABORT,'SUBSCRIPTION_INVALID') END;
END;
--> statement-breakpoint
CREATE TRIGGER appointment_update_overlap BEFORE UPDATE OF starts_at,ends_at,barber_id ON appointments WHEN NEW.status NOT IN('cancelled','no_show') BEGIN
 SELECT CASE WHEN EXISTS(SELECT 1 FROM appointments a WHERE a.id<>NEW.id AND a.barber_id=NEW.barber_id AND a.status NOT IN('cancelled','no_show') AND a.starts_at<NEW.ends_at AND a.ends_at>NEW.starts_at) THEN RAISE(ABORT,'SLOT_CONFLICT') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM blocks b WHERE (b.barber_id=NEW.barber_id OR b.barber_id IS NULL) AND b.starts_at<NEW.ends_at AND b.ends_at>NEW.starts_at) THEN RAISE(ABORT,'BLOCKED') END;
END;
--> statement-breakpoint
CREATE TRIGGER block_conflict_guard BEFORE INSERT ON blocks BEGIN
 SELECT CASE WHEN EXISTS(SELECT 1 FROM appointments a WHERE (a.barber_id=NEW.barber_id OR NEW.barber_id IS NULL) AND a.status IN('booked','waiting','in_service') AND a.starts_at<NEW.ends_at AND a.ends_at>NEW.starts_at) THEN RAISE(ABORT,'EXISTING_BOOKINGS') END;
END;
--> statement-breakpoint
CREATE TRIGGER commission_on_completion AFTER UPDATE OF status ON appointments WHEN NEW.status='completed' AND OLD.status<>'completed' BEGIN
 INSERT INTO commissions(id,appointment_id,barber_id,base_cents,barber_cents,house_cents,bps_snapshot,kind,created_at) VALUES(NEW.id,NEW.id,NEW.barber_id,COALESCE(NEW.charged_cents,0),CASE WHEN NEW.subscription_id IS NOT NULL OR NEW.owner_snapshot=1 THEN 0 ELSE CAST(round(NEW.charged_cents*NEW.commission_bps/10000.0) AS INTEGER) END,CASE WHEN NEW.subscription_id IS NOT NULL THEN 0 WHEN NEW.owner_snapshot=1 THEN NEW.charged_cents ELSE NEW.charged_cents-CAST(round(NEW.charged_cents*NEW.commission_bps/10000.0) AS INTEGER) END,NEW.commission_bps,CASE WHEN NEW.subscription_id IS NULL THEN 'single' ELSE 'subscription_pending' END,NEW.updated_at);
END;
--> statement-breakpoint
CREATE TRIGGER receipt_guard BEFORE INSERT ON receipts BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM appointments WHERE id=NEW.appointment_id AND status='completed' AND subscription_id IS NULL) THEN RAISE(ABORT,'NOT_PAYABLE') END;
 SELECT CASE WHEN NEW.amount_cents+COALESCE((SELECT SUM(amount_cents) FROM receipts WHERE appointment_id=NEW.appointment_id),0)>(SELECT charged_cents FROM appointments WHERE id=NEW.appointment_id) THEN RAISE(ABORT,'OVERPAYMENT') END;
 SELECT CASE WHEN EXISTS(SELECT 1 FROM cash_sessions WHERE day=date(NEW.received_at,'unixepoch','-3 hours') AND closed_at IS NOT NULL) THEN RAISE(ABORT,'CASH_CLOSED') END;
END;
--> statement-breakpoint
CREATE TRIGGER payout_guard BEFORE INSERT ON payout_allocations BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM commissions c JOIN payouts p ON p.id=NEW.payout_id WHERE c.id=NEW.commission_id AND c.barber_id=p.barber_id AND c.kind='single') THEN RAISE(ABORT,'INVALID_COMMISSION') END;
 SELECT CASE WHEN NEW.amount_cents+COALESCE((SELECT SUM(amount_cents) FROM payout_allocations WHERE commission_id=NEW.commission_id),0)>(SELECT c.barber_cents-COALESCE((SELECT SUM(r.barber_adjustment_cents) FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.appointment_id=c.appointment_id),0) FROM commissions c WHERE c.id=NEW.commission_id) THEN RAISE(ABORT,'COMMISSION_ALREADY_PAID') END;
 SELECT CASE WHEN NEW.amount_cents+COALESCE((SELECT SUM(amount_cents) FROM payout_allocations WHERE payout_id=NEW.payout_id),0)>(SELECT amount_cents FROM payouts WHERE id=NEW.payout_id) THEN RAISE(ABORT,'PAYOUT_OVERALLOCATED') END;
END;
--> statement-breakpoint
CREATE TRIGGER refund_guard BEFORE INSERT ON refunds BEGIN
 SELECT CASE WHEN NEW.amount_cents+COALESCE((SELECT SUM(amount_cents) FROM refunds WHERE receipt_id=NEW.receipt_id),0)>(SELECT amount_cents FROM receipts WHERE id=NEW.receipt_id) THEN RAISE(ABORT,'REFUND_EXCEEDS_RECEIPT') END;
 SELECT CASE WHEN NEW.barber_adjustment_cents+COALESCE((SELECT SUM(r.barber_adjustment_cents) FROM refunds r JOIN receipts rc ON rc.id=r.receipt_id WHERE rc.appointment_id=(SELECT appointment_id FROM receipts WHERE id=NEW.receipt_id)),0)+COALESCE((SELECT SUM(pa.amount_cents) FROM payout_allocations pa JOIN commissions c ON c.id=pa.commission_id WHERE c.appointment_id=(SELECT appointment_id FROM receipts WHERE id=NEW.receipt_id)),0)>(SELECT barber_cents FROM commissions WHERE appointment_id=(SELECT appointment_id FROM receipts WHERE id=NEW.receipt_id)) THEN RAISE(ABORT,'SETTLED_COMMISSION_REQUIRES_REVIEW') END;
END;
