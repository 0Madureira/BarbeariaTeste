# Pendências para ativação comercial

O sistema está implementado, mas **não foi declarado homologado para produção comercial**. A demonstração privada usa dados identificados e nenhuma integração financeira ou de mensageria ativa.

| Dependência | Ação necessária |
|---|---|
| Cloudflare | Conta do proprietário, banco D1, bucket R2, domínio/DNS e medição de CPU no Worker real |
| Administrador | Bootstrap único com celular real, senha exclusiva e segredo seguro; remover chave inicial |
| Jornada comercial | Rodrigues confirma os profissionais, fotos autorizadas, durações e dias/horários reais |
| Telefone e recuperação | Meta Cloud API, template de autenticação aprovado e teste real de recebimento/validação de OTP |
| Asaas sandbox | Chave, webhook, domínio de checkout confirmado e primeira cobrança/renovação/cancelamento/estorno em conta real de sandbox |
| Pagamentos de produção | Conta aprovada, contrato/tarifas validados e autorização expressa; flag de produção permanece desligada |
| Atualização de cartão | Validar fluxo hospedado do Asaas disponível para a conta; não coletar cartão na barbearia |
| Pix / Pix Automático | Validar produto e elegibilidade; a implementação atual usa checkout de cartão recorrente, sem prometer Pix automático |
| WhatsApp | WABA, número, access token, app secret, Graph version, modelos e tarifas vigentes autenticadas no WhatsApp Manager |
| Comissão de assinantes | Decisão comercial ainda ausente. Não há percentual, valor fixo ou rateio escolhido |
| Mensagens antigas | Notificações sem configuração não são enviadas retroativamente de forma automática; revisar quais ainda fazem sentido |
| Privacidade | Identificação completa do controlador, contato, política de retenção, prazos e procedimento de atendimento aprovados pelo proprietário |
| Operação | Responsável por exportar backups, testar restauração, conferir caixa e acompanhar webhooks/erros |

O teste automatizado do provedor usa mock explícito, não uma conta Asaas sandbox real. Fotografias de profissionais não foram inventadas. Não houve cobrança, mensagem automática, contratação de plano pago ou alteração de domínio comercial.

Antes da abertura comercial, repetir a bateria no Cloudflare de destino, incluindo disputa de horário em D1 real e hash de senha com a CPU do plano contratado. O adaptador de desenvolvimento e os testes usam SQLite real, mas não substituem a homologação do runtime e dos provedores externos.
