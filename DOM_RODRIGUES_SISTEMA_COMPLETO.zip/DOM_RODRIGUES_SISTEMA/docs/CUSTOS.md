# Custos e fontes — consulta em 07/11/2026

Nenhum serviço pago foi contratado ou usado para cobrar clientes. As franquias dependem da conta do proprietário e não representam promessa de operação sempre gratuita.

| Recurso | Franquia / condição | Custo fora da condição gratuita |
|---|---|---|
| Frontend Static Assets / Pages | Assets estáticos gratuitos; Pages Free 500 builds/mês, 20 mil arquivos | Domínio separado; Pages Functions consome Workers |
| Workers API | Free: 100 mil requests/dia, CPU 10 ms | Paid a partir de US$5/mês, incluindo 10M requests e 30M CPU-ms/mês |
| D1 | Free: 5M linhas lidas/dia, 100 mil escritas/dia, 500 MB por banco e 5 GB por conta | Paid amplia limites e cobra consumo |
| R2 Standard | 10 GB-mês, 1M operações A e 10M B/mês; egress gratuito | US$0,015/GB-mês, US$4,50/M A, US$0,36/M B; habilitação de faturamento pode ser solicitada |
| Backup D1 | Time Travel: 7 dias Free / 30 dias Paid | Exportações independentes e sua guarda são responsabilidade do proprietário |
| Domínio | O domínio existente pode ser reutilizado | Renovação conforme registrador; preço não verificado para este domínio |
| WhatsApp oficial | Sem envio enquanto não configurado | Tarifa por categoria, país/moeda e condições vigentes; valor Brasil não verificado em fonte primária acessível nesta consulta |
| Asaas sandbox | Ambiente sem dinheiro real | Produção tem taxas conforme contrato do proprietário |
| Asaas Pix convencional | Referência pública padrão R$1,99/recebimento | Promoções iniciais existem e não foram tomadas como permanentes |
| Asaas cartão à vista | Referência pública padrão R$0,49 + 2,99% | Aproximadamente R$4,98 em R$150 e R$6,47 em R$200; confirmar assinatura, antecipação e condições da conta |

**Estimativa prudente:** o site estático e pequenos volumes de banco/arquivos podem caber nas franquias. O hash de senha robusto usa scrypt com 32 MiB de área de trabalho e deve ser medido em produção; é provável exigir Workers Paid por ultrapassar os 10 ms de CPU do Free. Isso é uma inferência técnica, não uma medição do Worker comercial. Não se reduziu o fator do hash para anunciar custo zero. Valores em dólar dependem de câmbio e impostos; não foi calculada conversão presumida.

A tabela pública de WhatsApp acessível exigiu login/retornou restrição. O proprietário precisa consultar a tarifa vigente no WhatsApp Manager antes de autorizar os envios. Links manuais `wa.me` não são disparos da API.

Fontes oficiais:

- [Workers: preços](https://developers.cloudflare.com/workers/platform/pricing/) e [limites](https://developers.cloudflare.com/workers/platform/limits/).
- [Static Assets: faturamento](https://developers.cloudflare.com/workers/static-assets/billing-and-limitations/).
- [Pages: limites](https://developers.cloudflare.com/pages/platform/limits/).
- [D1: limites](https://developers.cloudflare.com/d1/platform/limits/) e [recuperação](https://developers.cloudflare.com/d1/reference/time-travel/).
- [R2: preços](https://developers.cloudflare.com/r2/pricing/) e [ativação](https://developers.cloudflare.com/r2/get-started/).
- [Asaas: tarifas](https://www.asaas.com/precos-e-taxas), [sandbox](https://docs.asaas.com/docs/sandbox), [checkout recorrente](https://docs.asaas.com/docs/checkout-com-assinatura-recorrente) e [cancelamento de checkout](https://docs.asaas.com/reference/cancelar-um-checkout).
- [Meta: preços oficiais](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing).
- [Cloudflare: node:crypto](https://developers.cloudflare.com/workers/runtime-apis/nodejs/crypto/) e [OWASP: proteção de senhas](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html).
