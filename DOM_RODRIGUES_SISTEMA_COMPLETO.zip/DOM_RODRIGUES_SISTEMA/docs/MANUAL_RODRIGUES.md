# Manual do Rodrigues

## Começar

Abra a demonstração privada e use “Painel do Rodrigues”. O aviso superior identifica os dados de teste. “Testar como cliente” abre uma conta separada para reservar e consultar horários. Uma alteração salva continua depois de atualizar a página. Na implantação comercial, entre com seu telefone e senha exclusivos.

## Preparar a agenda

1. Em **Profissionais**, cadastre nomes verdadeiros e fotografias autorizadas. Selecione serviços executados, percentual avulso e agendamento online. Só Rodrigues administra.
2. Em **Expediente**, ative dias e preencha os intervalos de cada profissional. Exemplo: 09h–12h e 13h–19h deixa almoço livre de reservas. Datas excepcionais substituem a jornada semanal.
3. Em **Bloqueios**, registre férias, feriados e ausências. Se já existem reservas no período, o sistema exige remarcar ou cancelar primeiro.
4. Em **Serviços**, valide preços e durações. A duração inteira precisa caber no expediente. Alterações não modificam os valores já gravados nos atendimentos.
5. Em **Configurações**, ajuste antecedência, janela futura, limite de reservas e prazo de cancelamento.

## Acompanhar o dia

**Agenda / Calendário** oferece dia, semana e mês. O mês mostra quantidades por dia. Clique no dia para abrir a grade por profissional. O modo semanal permite comparar os dias da semana e consultar seus horários. Os filtros de profissional ficam à esquerda no desktop; no celular, a grade pode ser deslizada horizontalmente.

Abra um bloco para registrar chegada, iniciar, concluir, remarcar, cancelar ou registrar falta. O check-in alimenta a **Fila de atendimento** na ordem de chegada. As contagens vêm do banco.

**Novo agendamento** cria encaixes para clientes verificados. A administração pode dispensar antecedência e limite de horários do cliente, mas não pode sobrepor serviços, bloquear horários ocupados ou ultrapassar o expediente.

## Concluir e receber

Ao concluir, confira o valor cobrado. Se conceder desconto, informe o motivo. Escolha pagamento integral, parcial ou pendente e a forma de pagamento. Atendimento realizado e valor recebido permanecem separados.

Nos avulsos de outro profissional, o padrão é 40% para o barbeiro e 60% para a casa. Um corte de R$35 gera R$14 e R$21. Quando Rodrigues atende, os R$35 pertencem à casa. O percentual salvo no agendamento é preservado no histórico.

Serviços cobertos por assinatura geram consumo e produtividade, sem nova receita avulsa. A comissão fica **Pendente de parametrização**, fora do saldo automático de repasse.

## Repasses e ajustes

Em **Financeiro → Comissões**, selecione os atendimentos de um único profissional. Clique em **Registrar repasse**, informe valor integral ou parcial, forma, observação e comprovante opcional. O sistema vincula cada centavo às comissões quitadas, impedindo que o fechamento seguinte pague novamente o mesmo saldo.

Para corrigir um repasse, registre uma devolução somente depois de receber o valor do profissional. A devolução mantém o histórico original e reabre o saldo das comissões. Se houver estorno do serviço, registre-o depois para ajustar a obrigação correta. Comissão já paga não pode ser reduzida silenciosamente por um estorno.

**Recebimentos** mostra pendências de serviços concluídos, pagamentos e estornos. **Despesas** registra custos e reversões sem apagar o original. Formas e categorias podem ser configuradas.

## Caixa

Abra o caixa de hoje informando o dinheiro inicial. No fechamento, conte o dinheiro físico. O esperado considera entradas em dinheiro, despesas, repasses, devoluções e estornos. Pix e cartões aparecem nos recebimentos, sem entrar no dinheiro contado. Depois do fechamento, novos lançamentos da mesma data são recusados. Não feche o caixa antes de registrar o último movimento.

O resultado operacional é estimado: não é lucro líquido e não inclui custos ou impostos que não foram lançados. Comissões por competência e repasses pagos não são descontados duas vezes.

## Clientes e clube

Em **Clientes**, procure nome ou telefone, consulte histórico e filtre sem retorno há 30, 60 ou 90 dias. Um cliente novo pode ter cadastro inicial feito por Rodrigues, mas precisa criar sua senha e verificar o telefone antes de reservar. Nenhuma propaganda é disparada automaticamente.

Em **Serviços e planos**, configure os serviços incluídos e abra a contratação apenas depois de validar as regras e o provedor. Valores iniciais provisórios: Corte R$150/mês; Corte + Barba R$200/mês. Não há limite mensal oculto de usos. Na demonstração, a solicitação do cliente só libera benefícios depois de **Confirmar pagamento de teste** no painel; isso não movimenta dinheiro.

Em produção/sandbox externo, o provedor confirma o pagamento. **Conciliar provedor** consulta cobranças e corrige o estado com dados autenticados. O cliente consulta benefícios, histórico e cancela a renovação na própria conta.

## WhatsApp e privacidade

Configurações mostra o estado real das integrações e das notificações. Sem credenciais, o estado é configuração pendente. “Preparar lembrete manual” abre um texto para sua revisão no WhatsApp; não envia sozinho. Confira o consentimento antes de comunicar.

O cliente exporta seus dados, altera nome, senha e preferências e registra pedidos de privacidade. Analise os pedidos na auditoria, confirme a identidade e os prazos de retenção. Nunca compartilhe o acesso administrativo.
