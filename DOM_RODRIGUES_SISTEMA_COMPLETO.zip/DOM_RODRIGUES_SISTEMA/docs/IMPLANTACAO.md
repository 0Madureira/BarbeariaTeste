# Implantação na conta Cloudflare do proprietário

## Arquitetura

O frontend foi mantido em HTML/CSS/JS. A configuração principal usa Workers Static Assets com API no mesmo domínio, D1 e R2 privado. Essa alternativa evita cookies e CORS entre Pages e Workers e permite publicação única. A preferência por Cloudflare foi preservada. Pages também pode servir o frontend, desde que `/api/*` e `/media/*` sejam encaminhados ao Worker no mesmo domínio; não publicar apenas `public/` esperando que o banco funcione.

O build específico da demonstração incorpora os assets no Worker para o ambiente privado. Na implantação comercial, `wrangler.jsonc` usa Static Assets, sem incorporar fotos e fontes em cada execução.

## 1. Conta e recursos

Use a conta do proprietário. Instale a versão estável atual do Wrangler pela distribuição oficial (`npm install --save-dev wrangler`) e autentique com `npx wrangler login` no computador do responsável.

```bash
npx wrangler d1 create dom-rodrigues
npx wrangler r2 bucket create dom-rodrigues-private
```

Copie o ID real do banco para `wrangler.jsonc`. Verifique o nome do bucket. A ativação do R2 pode pedir habilitação de faturamento mesmo dentro da franquia gratuita; não ativada por este projeto. O arquivo `.openai/hosting.json` pertence à demonstração privada e não é a configuração da conta Cloudflare do proprietário.

## 2. Segredos e ambiente

Gere dois segredos diferentes, cada um com pelo menos 32 bytes aleatórios. Não reutilize senha pessoal e não coloque valores em arquivos versionados:

```bash
npx wrangler secret put AUTH_PEPPER
npx wrangler secret put BOOTSTRAP_TOKEN
```

Mantenha `DEMO_MODE=false`, `ASAAS_MODE=sandbox`, `PRODUCTION_PAYMENTS_ENABLED=false` e `WHATSAPP_ENABLED=false`. Os nomes completos estão em `.env.example`. `AUTH_PEPPER` é parte da proteção das senhas: guarde cópia segura separada do banco. Perdê-lo exige recuperação das senhas dos usuários.

O hash usa scrypt N=32768, r=8, p=3, salt aleatório e pré-hash HMAC com segredo do servidor. Não reduza esses parâmetros para caber no plano gratuito. Medir CPU de login no Worker real; o plano Free tem 10 ms e pode exigir Workers Paid. Em testes Node locais o fluxo completo de cadastro/login/recuperação usa esse fator integral.

## 3. Banco e publicação técnica

```bash
npx wrangler d1 migrations apply dom-rodrigues --remote
npx wrangler deploy
```

Esses comandos são instruções para execução posterior pelo responsável. O agente não publicou comercialmente na conta Cloudflare do proprietário. Proteja a implantação em validação contra visitantes públicos até a homologação. Nunca edite migrações já aplicadas: crie novas migrações.

## 4. Administrador inicial

Faça `POST /api/auth/bootstrap` por uma ferramenta HTTP de confiança, usando a origem exata do site, Content-Type JSON e header `X-Bootstrap-Token` com o segredo configurado. O corpo tem `phone` (celular com DDD) e `password` (mínimo 16 caracteres). Digite a senha localmente, sem enviá-la em conversas. O endpoint só permite um administrador, chamado Rodrigues; os demais profissionais não têm login. Remova `BOOTSTRAP_TOKEN` após o sucesso. Entre no `/admin` com telefone e senha.

O cadastro inicial inclui os oito serviços e os dois planos solicitados. Os planos ficam com contratação fechada; a agenda inicia sem expediente e com o agendamento online do proprietário fechado. Rodrigues deve validar valores, durações, benefícios, perfis e horários antes da abertura. Isso evita inventar a jornada comercial.

## 5. Verificação e WhatsApp

Configure `META_ACCESS_TOKEN`, `META_PHONE_NUMBER_ID`, `META_GRAPH_VERSION`, `META_APP_SECRET`, `META_WEBHOOK_VERIFY_TOKEN` e `META_AUTH_TEMPLATE` com a conta oficial do proprietário. O template de autenticação precisa estar aprovado e suportar OTP com botão copiar código. O aplicativo usa `POST /{PHONE_NUMBER_ID}/messages` da versão configurada.

Configure `/api/webhooks/meta`: GET valida o verify token; POST verifica HMAC-SHA256 do corpo bruto com o app secret. Os modelos transacionais são configurados via `PATCH /api/admin/settings` em `whatsapp_templates`, com as chaves `booking_confirmation`, `reminder_24h`, `booking_cancelled`, `booking_rescheduled`, `subscription_paid`, `subscription_due`. Os parâmetros enviados seguem os arrays no módulo `integrations.mjs` e os modelos precisam corresponder a eles.

`WHATSAPP_ENABLED=true` só depois da homologação e aprovação das tarifas. O cadastro em produção permanece bloqueado sem o canal de verificação. Os links manuais apenas preparam o WhatsApp; Rodrigues revisa e envia. Estados de envio ambíguo não são reenviados automaticamente, evitando mensagens duplicadas.

O Cron `*/10 * * * *` dispara processamento de lembretes, avisos e limpeza de sessões. Cron usa UTC; a lógica comercial usa America/Sao_Paulo. O endpoint administrativo de processamento permite validar a fila sem aguardar o Cron. A demonstração privada não depende de Cron provisionado para funcionar; não envia alertas.

## 6. Assinaturas Asaas

Use uma conta sandbox independente. Configure `ASAAS_API_KEY`, `ASAAS_WEBHOOK_TOKEN` (diferente da API key, pelo menos 32 caracteres) e `ASAAS_CHECKOUT_ORIGIN` (domínio de navegação sandbox confirmado na conta; não presumido). Base API sandbox: `https://api-sandbox.asaas.com/v3`.

Habilite webhooks PAYMENT_*, SUBSCRIPTION_* e CHECKOUT_* para `/api/webhooks/asaas`, com authToken que chega em `asaas-access-token`. A API consulta a cobrança atual no provedor antes de reconhecer o evento, preserva idempotência por evento e pagamento e distingue confirmação de liquidação. Checkout e callback visual não concedem benefícios.

Valide primeira cobrança, renovação, cancelamento, estorno, inadimplência, eventos fora de ordem, reconciliação e domínio do checkout. Registre a URL pública do webhook da conta de destino. O cancelamento da recorrência utiliza DELETE de assinatura; checkout pendente usa POST `checkouts/{id}/cancel`.

Produção exige chaves e conta próprias, `ASAAS_MODE=production`, `ASAAS_CHECKOUT_ORIGIN` validado e autorização expressa para `PRODUCTION_PAYMENTS_ENABLED=true`. Essa autorização não foi concedida nem aplicada. A atualização hospedada de cartão e Pix Automático permanecem dependentes de validação do produto/conta; não há coleta de cartão na barbearia.

## 7. Backup, restauração e retenção

Use Time Travel (7 dias Free / 30 dias Paid, conforme plano) e exportação periódica independente:

```bash
npx wrangler d1 export dom-rodrigues --remote --output backup.sql
```

Guarde o backup criptografado, fora do repositório e com acesso restrito. Copie os objetos R2 separadamente com ferramenta oficial compatível. Teste a restauração em banco e bucket novos antes de apontar a aplicação: importe o SQL com Wrangler, confirme chaves, contagens, saldos e arquivos. Nunca teste restauração sobrescrevendo o banco comercial.

Defina responsável, frequência de exportação e prazo de retenção antes do uso real. A aplicação limpa sessões e códigos expirados pelo Cron; não apaga automaticamente histórico financeiro nem logs necessários. Solicitações de privacidade entram na auditoria para análise pelo controlador. Replique e versione mudanças com migrações; mantenha rollback do código e backup do banco.
