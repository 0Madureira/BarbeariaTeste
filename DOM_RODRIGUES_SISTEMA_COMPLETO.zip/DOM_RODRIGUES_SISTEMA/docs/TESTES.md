# Relatório de testes — 07/11/2026

## Bateria automatizada

Comando: `npm test`. Node.js 24, SQLite real, mesmo handler Worker da aplicação. São **22 testes de integração**. As chamadas a provedores externos são mocks controlados explicitamente; nenhum pagamento ou WhatsApp real é realizado.

| Fluxo | Evidência coberta |
|---|---|
| Cadastro e autenticação | Conta não entra sem OTP; hash scrypt integral; login; recuperação invalida sessões antigas |
| Produção sem canal de telefone | Cadastro bloqueado; bootstrap exige segredo e administrador único |
| Permissões | APIs administrativas negadas a cliente, propriedade individual, CSRF e Origin obrigatórios |
| Reserva e persistência | Confirmação automática, duração completa, limite futuro; reabre arquivo SQLite e encontra a reserva |
| Concorrência | Duas solicitações simultâneas sobrepostas: exatamente uma vence e uma é recusada |
| Idempotência | Repetir a chave retorna a reserva existente; reutilizar com dados diferentes é recusado |
| Disponibilidade | Serviço não cabe no fim da jornada; bloqueios impedem reserva; bloqueio ocupado é recusado |
| Cancelamento e remarcação | Transação libera horário antigo e mantém novo sem abrir espaço para duplicação |
| Profissionais e fotos | Upload PNG, associação, expediente, desativação, preservação dos horários e rejeição de SVG |
| Comissão avulsa | R$35: R$14 para barbeiro, R$21 casa; Rodrigues: R$35 casa; recebimento pendente separado |
| Repasse parcial e integral | R$5 + R$9 quitam R$14; duplicação e excedente recusados; cada valor vinculado à comissão |
| Desconto e histórico | Comissão sobre R$30 cobrados; mudança posterior de preço/percentual não reescreve passado |
| Estorno | Ajusta comissão não paga sem apagar recebimento; bloqueia estorno excedente |
| Caixa | Fechamento bloqueia novos recebimentos/despesas; falha desfaz a conclusão inteira |
| Asaas sandbox controlado | Checkout pendente; webhook autenticado; confirmação única; cancelamento conserva período pago |
| Consumo do assinante | Valor avulso zero, produtividade registrada, comissão pendente e receita não duplicada |
| WhatsApp sem configuração | Nunca marca enviado; processamento retorna configuração pendente |
| Relatórios e CSV | Dados consultados no banco, valores apurados e proteção contra fórmulas em exportação |
| Devolução de repasse | Devolução recebida reabre saldo; estorno subsequente ajusta obrigação; histórico imutável |
| Conclusão simultânea | Exatamente um recebimento e uma comissão, mesmo com duas tentativas |
| Renovação | Segundo pagamento estende validade; CONFIRMED não é apresentado como valor já liquidado |
| Benefício revogado | Impede atendimento gratuito após revogação; conversão avulsa exige motivo e auditoria |

## Revisão no navegador

- Site público e painel com a identidade preto/dourado e assets originais.
- Agenda diária por profissional, estados reais e calendário mensal com contagem diária.
- Reserva demonstrativa concluída na interface: profissional → serviço → dia → horário → confirmação automática.
- Sessão e registros consultados após recarregar a página.
- Layout de celular revisado em viewport real de iframe 390 × 844 px; menu lateral e agenda navegáveis, com rolagem interna na grade.
- Verificação de sintaxe de backend, frontend, scripts, testes e Worker compilado: `npm run check`.

## Limites da verificação

Não foi utilizada a conta comercial Cloudflare, Meta ou Asaas do proprietário. A bateria SQLite não substitui teste de disputa no D1 de destino. A autenticação precisa ser medida no Worker real para decidir o plano de CPU. A homologação real de OTP, fotos em R2 comercial, checkout, recorrência, cartão e tarifas depende das credenciais em `PENDENCIAS.md`. As políticas de privacidade e retenção precisam de validação do controlador antes do uso real.

O resultado não significa aprovação comercial ou autorização de cobrança. O ambiente de demonstração é privado e explicitamente identificado.
