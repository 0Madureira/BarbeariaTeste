import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync,mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
export function openDatabase(path=':memory:'){
  if(path!==':memory:')mkdirSync(dirname(path),{recursive:true});const sqlite=new DatabaseSync(path);sqlite.exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
  if(path!==':memory:')sqlite.exec('PRAGMA journal_mode=WAL;');
  class Statement{
    constructor(sql,values=[]){this.sql=sql;this.values=values;}
    bind(...v){return new Statement(this.sql,v);}
    async all(){return {success:true,results:sqlite.prepare(this.sql).all(...this.values),meta:{}};}
    async first(column){const row=sqlite.prepare(this.sql).get(...this.values);return row?(column?row[column]:row):null;}
    async run(){const result=sqlite.prepare(this.sql).run(...this.values);return {success:true,results:[],meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}};}
    execute(){const q=sqlite.prepare(this.sql);const returns=/^\s*(SELECT|PRAGMA|WITH)\b/i.test(this.sql)||/\bRETURNING\b/i.test(this.sql);if(returns)return {success:true,results:q.all(...this.values),meta:{}};const result=q.run(...this.values);return {success:true,results:[],meta:{changes:Number(result.changes)}};}
  }
  const db={prepare:sql=>new Statement(sql),async batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}},async exec(sql){sqlite.exec(sql);return {count:1};},close(){sqlite.close();},sqlite};
  return db;
}
export function migrate(db,root=resolve(import.meta.dirname,'..')){db.sqlite.exec('CREATE TABLE IF NOT EXISTS _local_migrations(name TEXT PRIMARY KEY,applied_at INTEGER NOT NULL)');for(const file of readdirSync(resolve(root,'db/migrations')).filter(f=>f.endsWith('.sql')).sort()){if(db.sqlite.prepare('SELECT name FROM _local_migrations WHERE name=?').get(file))continue;const sql=readFileSync(resolve(root,'db/migrations',file),'utf8');db.sqlite.exec('BEGIN IMMEDIATE');try{for(const statement of sql.split('--> statement-breakpoint'))if(statement.trim())db.sqlite.exec(statement);db.sqlite.prepare('INSERT INTO _local_migrations VALUES(?,?)').run(file,Date.now());db.sqlite.exec('COMMIT');}catch(e){db.sqlite.exec('ROLLBACK');throw e;}}}
