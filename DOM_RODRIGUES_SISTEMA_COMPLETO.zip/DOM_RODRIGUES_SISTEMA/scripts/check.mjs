import {spawnSync} from 'node:child_process';
import {readdirSync,readFileSync,existsSync} from 'node:fs';
import {resolve,join} from 'node:path';
const root=resolve(import.meta.dirname,'..');let failed=false;
for(const dir of ['backend','public','scripts','tests'])for(const file of readdirSync(resolve(root,dir))){if(!/\.(m?js)$/.test(file))continue;const r=spawnSync(process.execPath,['--check',resolve(root,dir,file)],{encoding:'utf8'});if(r.status){console.error(r.stderr);failed=true;}}
if(existsSync(resolve(root,'dist/server/index.js'))){const r=spawnSync(process.execPath,['--check',resolve(root,'dist/server/index.js')],{encoding:'utf8'});if(r.status){console.error(r.stderr);failed=true;}}
if(failed)process.exit(1);console.log('JavaScript syntax verified.');
